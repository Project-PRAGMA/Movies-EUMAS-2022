import os

from es.data_config import data_folder_netflix_raw, data_folder_movielens_raw, data_folder_goodreads_raw

data_folder_netflix_tmp=f'{data_folder_netflix_raw}/tmp'
data_folder_netflix_tmp_movies = f'{data_folder_netflix_tmp}/movies'

for folder in [data_folder_netflix_raw, data_folder_movielens_raw, data_folder_netflix_tmp]:
    if not os.path.exists(folder):
        os.makedirs(folder)

# targz_path=f'{data_folder_netflix_raw}/nf_prize_dataset.tar.gz'

# -------------------- movielens

print(f"downloading the raw movielens datasets to {data_folder_movielens_raw}")
# os.system(f'wget -P {data_folder_movielens_raw} http://files.grouplens.org/datasets/movielens/ml-100k.zip ')
# os.system(f'wget -P {data_folder_movielens_raw} http://files.grouplens.org/datasets/movielens/ml-1m.zip ')
# os.system(f'wget -P {data_folder_movielens_raw} http://files.grouplens.org/datasets/movielens/ml-10m.zip ')
# os.system(f'wget -P {data_folder_movielens_raw} http://files.grouplens.org/datasets/movielens/ml-25m.zip ')

# -------------------- netflix

# get manually: https://www.kaggle.com/netflix-inc/netflix-prize-data/data#
# mv ~/Downloads/netflix-prize-data.zip ~/tmp/esearch/netflix_raw/

# os.system(f'wget -P {data_folder_netflix_raw} https://archive.org/download/nf_prize_dataset.tar ')
# os.system(f'tar -C "{data_folder_netflix_tmp}" -xvf {targz_path}')
# print("tar doesn't cope well with that amount of files. untar using mac - double click")
# os.system(f'echo tar -C "{data_folder_netflix_tmp_movies}" -xv {data_folder_netflix_tmp}/training_set.tar')

# import tarfile
# with tarfile.open(targz_path, "r:gz") as tar:
#     for tarinfo in tar:
#         print(tarinfo.name, "is", tarinfo.size, "bytes in size and is", end="")
#         if tarinfo.isreg():
#             print("a regular file.")
#         elif tarinfo.isdir():
#             print("a directory.")
#         else:
#             print("something else.")


os.system(f'wget -P {data_folder_goodreads_raw} https://github.com/zygmuntz/goodbooks-10k/releases/download/v1.0/goodbooks-10k.zip ')
