from data.goodreads_data import GoodreadsData
from es.data_config import data_netflix_parquet, \
    data_movielens_100k, data_movielens_1m, data_movielens_25m, data_goodreads_parquet
from es.data.movielens_data import MovielensData
from es.data.netflix_data import NetflixData


def setup():

    # ====================== GOODREADS

    data = GoodreadsData(data_goodreads_parquet)
    data.convert_raw2parquet()

    # ====================== NETFLIX
    #
    # data = NetflixData(data_netflix_parquet)
    # data.convert_raw2parquet(n_movies=1000000)

    # ====================== MOVIELENS

    MovielensData(data_movielens_100k).convert_raw2parquet()
    MovielensData(data_movielens_1m).convert_raw2parquet()
    MovielensData(data_movielens_25m).convert_raw2parquet()

    pass


if __name__ == "__main__":
    setup()
