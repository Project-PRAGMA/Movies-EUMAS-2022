import os
import random
from datetime import datetime

import pandas as pd
import pytest
# noinspection PyProtectedMember
from pandas._testing import assert_frame_equal

import data_config
import scorers
import test_utils
import utils
from data.movielens_data import MovielensData
from elections import InstacartDataFrames, ALGO_ILP
from electionutils import ALGO_GREEDY, ALGO_SA
from runner.scenario_runner import ScenarioRunner


# F I X T U R E S ==========================================================


@pytest.fixture(scope="function")
def PARAMS_FIX():
    params = utils.dotdict(dict(
        exp_name='tmp',
        k=10,
        searchterms=['Hot Shots! (1991)'],
        filtering=dict(sample_orders=None),
        rules=["HUV_0", "HUV_1", "HUV_2", "HUV_3", ],
        anneal_settings={'tmax': 9900.0, 'tmin': 0.6, 'steps': 50000, 'updates': 10},
        scorer_metrics=['tfidfto2'],
        scorer_funcs=[scorers.AgentSpreadScoringStrategy.from_found_df_sorted_nosearchterm]
    ))
    # brackets need escaping in a regular expression
    params.searchterms = [t.replace('(', '.').replace(')', '.') for t in params.searchterms]
    return params


@pytest.fixture(scope="session")
def SMALL_FRAMES_FIX():
    return _load_frames(sample_n_orders=200)


@pytest.fixture(scope="session")
def SUPER_SMALL_FRAMES_FIX():
    return _load_frames(sample_n_orders=40, sample_n_products=20)


@pytest.fixture(scope="session")
def ORIGINAL_FRAMES_FIX():
    return _load_frames()


# T E S T S ==========================================================

@pytest.mark.parametrize('algo,version',
                         [(ALGO_GREEDY, v) for v in [0, 1, 2, 3, 4]] +
                         [(ALGO_SA, v) for v in [0, 1, 2, '2d']],
                         )
def test_algos_quick(SMALL_FRAMES_FIX, PARAMS_FIX, algo, version):
    PARAMS_FIX['anneal_settings']['steps'] = 1000
    _validate_algo_version("quick", algo, version, PARAMS_FIX, SMALL_FRAMES_FIX)


@pytest.mark.parametrize('algo,version',
                         [(ALGO_GREEDY, v) for v in [0, 1, 2, 3, 4]] +
                         [(ALGO_SA, v) for v in [0, 1, 2, '2d']] +
                         [(ALGO_ILP, v) for v in [0]],
                         )
def test_algos_quick_ilp(SUPER_SMALL_FRAMES_FIX, PARAMS_FIX, algo, version):
    PARAMS_FIX['searchterms'] = ["Reservoir Dogs (1992)"]
    PARAMS_FIX['anneal_settings']['steps'] = 1000
    PARAMS_FIX['k'] = 3
    _validate_algo_version("quick", algo, version, PARAMS_FIX, SUPER_SMALL_FRAMES_FIX)

@pytest.mark.slow
@pytest.mark.parametrize('algo,version',
                         reversed(
                             [(ALGO_SA, v) for v in [2]] +
                             [(ALGO_GREEDY, v) for v in [4]]
                         ))
def test_algos_system(ORIGINAL_FRAMES_FIX, PARAMS_FIX, algo, version):
    _validate_algo_version("system", algo, version, PARAMS_FIX, ORIGINAL_FRAMES_FIX)


# U T I L S ==========================================================

def _validate_algo_version(key, algo, version, PARAMS, iframes):
    params = utils.dotdict(PARAMS.copy())
    params_hash = test_utils.param_hash(params)[:6]
    frames_hash = utils.str_hash(str(iframes.df_products.product_name.tolist()))[:6]

    algo_prefix = f"{algo}{version}." if version is not None else ""
    params.rules = [algo_prefix + rule for rule in params.rules]

    runner = ScenarioRunner(iframes, params, seed=13)
    df_result = runner.run(verbose=0, return_df=True, include_unity=False, seed=13)

    local_path = f"{key}/params={params_hash}_frames={frames_hash}/algo={algo_prefix}csv"

    # uncomment to save to 'create new official versions' if needed
    tmp_filename = f"../out/test/algos/{local_path}"
    os.makedirs(os.path.dirname(tmp_filename), exist_ok=True)
    df_result.to_csv(tmp_filename, index=False)

    df_official = pd.read_csv(f"data/official/algos/{local_path}")

    columns_to_compare = set(df_official.columns).difference(['rule', 'algo_version'])

    assert_frame_equal(df_result[columns_to_compare], df_official[columns_to_compare], check_dtype=False)


def _show_benchmark(prev, cur, comment=""):
    print(
        f"BENCHMARK ({comment}): {prev.algo}{prev.version}/{cur.algo}{cur.version} speed up factor) "
        f"= {prev.runtime / cur.runtime:.1f} ({prev.runtime:.2f} / {cur.runtime:.2f})")


def _load_frames(sample_n_orders=None, sample_n_products=None):
    dataset = data_config.data_movielens_25m
    print(f'loading the data from {dataset}')
    idata = MovielensData(dataset)
    iframes = InstacartDataFrames.from_data(idata)
    if sample_n_orders is not None:
        iframes = iframes.sample(n_orders=sample_n_orders, n_products=sample_n_products, random_state=1, inplace=False)
    return iframes
