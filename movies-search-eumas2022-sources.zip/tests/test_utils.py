from utils import str_hash


def param_hash(params):
    """
    prepare a hash to check if params have changed in meaningful way
    """
    str_params = params.copy()
    # need to keep just the strategy class name from:
    #   original: '<function AgentSpreadScoringStrategy.from_found_df_sorted_nosearchterm at 0x7fde20f7e560>'
    str_params['scorer_funcs'] = None if params['scorer_funcs'] is None else [str(x).replace(' ', '.').split('.')[1] for
                                                                              x in params['scorer_funcs']]
    return str_hash(str_params)


