import pandas as pd
import pytest
from abcvoting import abcrules

from experiments.counting_rradius_raw import run_counting_rr_raw, aggregate_results, PERTURB_REMOVE, \
    PERTURB_ADD, PERTURB_SWAP, perturb
from elections_raw import run_raw_elections, PrefProfile


def test_basic():
    profile = PrefProfile.generate_uniform(n_resources=5, n_agents=5, density=0.5)
    profile.print()

    committee, score = run_raw_elections(profile=profile, rule='seqphragmen', k=3)

    print(committee, score)


@pytest.mark.parametrize('perturbation_type',
                         [
                             PERTURB_ADD,
                             PERTURB_REMOVE,
                             PERTURB_SWAP,
                         ])
def test_perturb(perturbation_type):
    profile = PrefProfile.generate_uniform(n_resources=5, n_agents=5, density=0.5)
    profile.print()
    new_profile = perturb(profile, perturbation_level=.2, perturbation_type=perturbation_type)
    new_profile.print()


def test_phragmen():
    profile = PrefProfile.generate_uniform(n_resources=5, n_agents=5, density=0.5)
    profile.print()

    abc_profile = profile.to_abc_profile()

    winner_ixs = abcrules.get_rule('seqphragmen').compute(abc_profile, 3, resolute=True)

    print(winner_ixs)


def test_counting_rr_raw():
    df = run_counting_rr_raw(
        perturbation_levels=[0.01, 0.1],
        perturbation_types=[PERTURB_ADD, PERTURB_REMOVE, PERTURB_SWAP],
        rules=['HUV_0', 'seqphragmen'],
        n_elections=10,
        k=3,
        gen_profile_funcs=[
            lambda: PrefProfile.generate_uniform(
                n_resources=100,
                n_agents=100,
                density=.2
            ),
            # lambda: generate_named_profile(
            #     n_resources=100,
            #     n_agents=100,
            #     density=.5
            # ),
            # lambda: generate_named_profile(
            #     n_resources=100,
            #     n_agents=100,
            #     density=.7
            # ),
        ],
        # seed=13
    )

    result = aggregate_results(df)

    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_rows', None)
    pd.set_option('max_colwidth', None)
    pd.set_option('expand_frame_repr', False)

    print(result)
