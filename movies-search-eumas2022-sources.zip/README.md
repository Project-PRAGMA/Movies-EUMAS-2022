# Setup

(tested on MacOS Big Sur)

## Data
You will need to download the datasets for use (this might imply agreeing to license terms).
You can configure where the data lives using the file: `data.py`.
- MovieLens: https://grouplens.org/datasets/movielens/
  (variable: `data_folder_movielens_raw`, finally `ml-25.zip` should be available at `{data_folder_movielens_raw}/ml-25m.zip` )
- Netflix: https://www.kaggle.com/netflix-inc/netflix-prize-data
  (variable: `data_folder_netflix_raw`)
- Goodreads: https://maciejkula.github.io/spotlight/datasets/goodbooks.html
  (variable: `data_folder_goodreads_raw`)

## Initialise

- `make conda-env-setup` (you may have to install `pyarrow` with pip)
- `conda install dask distributed -c conda-forge` to install dask distributed
- `conda activate esearch`
- `make initialise_data`
  (Data conversion is performed for performance reasons and must be done only once)
- `make test`

## Run experiments
- `make prod`

## How to run a movielens notebook
- `conda activate esearch`
- `make notebooks-open`
- in jupter open up `notebooks/runner-movielens.ipynb`
- select the movie you want to search for`search_term="^Hot Shots! .1991."`
- run all notebook cells, scroll down for the results
