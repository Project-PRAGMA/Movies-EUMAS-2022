import numpy as np


class Metric():
    @staticmethod
    def _to_col_name(s):
        return s.replace("_", "__").replace(".", "_")

    def get_name(self):
        raise NotImplementedError

    @staticmethod
    def from_dict(d):
        if d['kind'] == MetricBM25.get_kind():
            return MetricBM25(d['k'], d['b'])
        elif d['kind'] == MetricTfxIdf.get_kind():
            return MetricTfxIdf(d['base'])


class MetricBM25(Metric):
    """
        :param k: approximately the weight on TF (1.2-2.0)
        :param b: (0..1) document size impact on weiging TF (0-document length has no impact, 1-large document size decreases the TF weight, and vice versa for small)
    """
    def __init__(self, k, b):
        self.b = b
        self.k = k

    @staticmethod
    def get_kind():
        return 'bm25'

    def get_name(self):
        return self._to_col_name(f'bm25_{self.k}_{self.b}')

    def calc(self, idf, tf, dl, avgdl):
        """
        :param idf: idf series or a single value
        :param tf: tf series of a single value
        :param dl: document length (i.e. number of voters approving the search item)
        :param avgdl: average document length (across all search items)
        """
        return idf * (tf * (self.k + 1) / (tf + self.k * (1 - self.b + 1.0 * self.b * dl / avgdl)))


class MetricTfxIdf(Metric):
    def __init__(self, base):
        self.base = base

    @staticmethod
    def get_kind():
        return 'tfxtoidf'

    def get_name(self):
        return self._to_col_name(f'tf{self.base}toidf')

    def calc(self, tf, idf):
        return tf * np.power(self.base, idf)