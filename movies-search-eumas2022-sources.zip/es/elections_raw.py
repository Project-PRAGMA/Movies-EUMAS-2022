import copy
import pickle
import random
from typing import Dict, List

import pyximport
from abcvoting import abcrules
from abcvoting.preferences import Profile
from mapel.elections.objects.ApprovalElection import ApprovalElection

from Rules import rules_dict
from elections import Elections
from utils import abc_rules

pyximport.install()
from OwaGreedy4 import OwaGreedy4


class PrefProfile:

    def __init__(self, preferences: List[Dict[int, float]], n_resources: int, n_agents: int, name: str):
        self.name = name
        self.n_agents = n_agents
        self.n_resources = n_resources
        self.preferences = preferences

    @staticmethod
    def generate_uniform(n_resources, n_agents, density):
        profile = [{r: 1 for r in random.sample(range(n_resources), int(density * n_resources))} for _ in
                   range(n_agents)]
        return PrefProfile(profile, n_resources, n_agents,
                           name=f"uniform-n_resources={n_resources}-n_agents={n_agents}-density={density}"
                           )

    @staticmethod
    def generate_mapel(n_resources, n_agents, model_id, phi, p):
        election = ApprovalElection("virtual", "virtual", num_candidates=n_resources, num_voters=n_agents,
                                    model_id=model_id)
        election.prepare_instance(params=dict(phi=phi, p=p))
        profile = [{r: 1 for r in agent_approvals} for agent_approvals in election.votes]
        return PrefProfile(profile, n_resources, n_agents,
                           name=f"{model_id}-n_resources={n_resources}-n_agents={n_agents}-p={p}-phi={phi}"
                           )

    @staticmethod
    def from_search_term(election_utils, search_term, max_resources, max_agents):
        search_df = election_utils.find_products(search_term, min_order_count=1, max_order_count=1000000)

        filtered_full_elections = election_utils.create_filtered_elections(
            search_df, idf_map=None, similarity=None, steps=1, utility_scorer=None)

        filtered_elections = filtered_full_elections.sample(
            max_candidates=max_resources, max_voters=max_agents, random_state=13)

        ut_profile = filtered_elections.generate_utility_profile()

        def compact_profile(profile):
            """
            profile: List[Dict[int, int]]
            """
            cid2cix = {}
            new_profile = []
            current_cix = 0
            for agent in profile:
                new_agent = {}
                new_profile.append(new_agent)
                for cid in agent.keys():
                    if not cid in cid2cix:
                        cid2cix[cid] = current_cix
                        current_cix += 1
                    new_agent[cid2cix[cid]] = 1
            return new_profile

        ut_profile = compact_profile(ut_profile)

        n_resources = filtered_elections.candidate_count
        n_agents = filtered_elections.voter_count
        pprofile = PrefProfile(
            ut_profile,
            n_resources=n_resources,
            n_agents=n_agents,
            name=f"movielens-n_resources={n_resources}-n_agents={n_agents}-movie={search_term}"
        )
        return pprofile

    @staticmethod
    def to_file(self, filepath):
        with open(filepath, 'wb') as f:
            pickle.dump(self, f)

    @staticmethod
    def from_file(filepath):
        with open(filepath, 'rb') as f:
            y = pickle.load(f)
        return y

    def to_abc_profile(self):
        p = Profile(num_cand=self.n_resources)
        prefs = [list(agent.keys()) for agent in self.preferences]
        p.add_voters(prefs)
        return p

    def deepcopy(self):
        return copy.deepcopy(self)

    def print(self):
        matrix = [[" " for _ in range(self.n_resources)] for _ in self.preferences]
        for aix, agent in enumerate(self.preferences):
            for rix in agent.keys():
                matrix[aix][rix] = '*'
        matrix = ["".join(row) for row in matrix]
        print()
        print("".join([str(x) for x in range(self.n_resources)]))
        print("\n".join(matrix))

    def size(self):
        return self.n_agents * self.n_resources

    def approval_count(self):
        return sum(len(agent) for agent in self.preferences)


def run_raw_elections(profile: PrefProfile, rule: str, k: int):
    if rule in abc_rules:
        abc_profile = profile.to_abc_profile()
        try:
            committee = abcrules.get_rule(rule).compute(abc_profile, k, resolute=True)[0]
        except ValueError as err:
            if "larger than the number of approved candidates" in str(err):
                committee = []
            else:
                raise

        score = None
    else:
        algo = OwaGreedy4(m=profile.n_resources, k=k, owa_vector=rules_dict[rule], pref_profile=profile.preferences)
        committee, score = algo.run()

    return committee, score
