import os
import zipfile

import pandas as pd

from es.data_config import data_folder_netflix_raw, data_folder_movielens_raw
from es.data.base_data import BaseData


class MovielensData(BaseData):
    def __init__(self, parquet_folder, verbose=1):
        super().__init__(parquet_folder, verbose)
        self.ml_set_name = parquet_folder.split('/')[-1].replace('movielens', 'ml').replace('_', '-')

    # INTERFACE =========================

    def read_df_products(self):
        return self.df_folder.read_df('products')

    def read_df_orders(self):
        return self.df_folder.read_df('orders')

    def read_df_order_products__all(self):
        return self.df_folder.read_df('order_products__all')

    def read_df_departments(self):
        return self.df_folder.read_df('departments')

    def read_df_aisles(self):
        return self.df_folder.read_df('aisles')

    def read_df_product_distances(self):
        raise NotImplemented

    def product_distances_filepath(self):
        raise NotImplemented

    # IMPLEMENTATION =========================

    def convert_raw2parquet(self):
        ml_sets = {
            # commented out, because - need to add genre retrieval to use this dataset again
            # 'ml-100k': dict(movies_path='ml-100k/u.item', movies_delimiter='|', ratings_path='ml-100k/u.data',
            #                 ratings_delimiter='\t',
            #                 movies_header=[
            #                     'id', 'title', 'release date', 'video release date', 'IMDb URL', 'unknown', 'Action',
            #                     'Adventure', 'Animation', 'Children', 'Comedy', 'Crime', 'Documentary', 'Drama',
            #                     'Fantasy', 'Film-Noir', 'Horror', 'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller',
            #                     'War', 'Western'
            #                 ]),
            'ml-1m': dict(movies_path='ml-1m/movies.dat', movies_delimiter='::', ratings_path='ml-1m/ratings.dat',
                          ratings_delimiter='::',
                          movies_header=[
                              'id', 'title', 'tags'
                          ]),
            'ml-10m': dict(movies_path='ml-10M100K/movies.dat', movies_delimiter='::',
                           ratings_path='ml-10M100K/ratings.dat', ratings_delimiter='::',
                           movies_header=[
                               'id', 'title', 'tags'
                           ]),
            'ml-25m': dict(movies_path='ml-25m/movies.csv', movies_delimiter=',', ratings_path='ml-25m/ratings.csv',
                           ratings_delimiter=',',
                           movies_header=[
                               'id', 'title', 'tags'
                           ],
                           ignore_header=True),
        }
        assert self.ml_set_name in ml_sets.keys(), f"unknown movie lens set name: {self.ml_set_name}"

        ml_set = ml_sets[self.ml_set_name]

        print(f'converting the movielens data to parquet: {self.df_folder.data_folder}')
        movies_df = MovielensData.read_raw_movies(self.ml_set_name, ml_set)
        products_df = movies_df[['id', 'title', 'main_genre']]
        products_df.columns = ['product_id', 'product_name', 'main_genre']
        products_df['aisle_id'] = 1
        products_df['department_id'] = 1
        self.df_folder.save_df(df=products_df, table_name='products')

        ratings_df = MovielensData.read_raw_ratings(self.ml_set_name, ml_set)
        print(f'!!!!!!!!!!!!!!!!!!!!!   count of ratings: {len(ratings_df)}')
        order_products_df = ratings_df[['user_id', 'movie_id']]
        order_products_df.columns = ['order_id', 'product_id']
        self.df_folder.save_df(df=order_products_df, table_name='order_products__all')

        order_df = pd.DataFrame(order_products_df.order_id.unique(), columns=['order_id'])
        order_df['user_id'] = order_df.order_id
        self.df_folder.save_df(df=order_df, table_name='orders')

        self.df_folder.save_df(df=pd.DataFrame([(1, "default")], columns=['aisle_id', 'aisle']), table_name='aisles')

        self.df_folder.save_df(df=pd.DataFrame([(1, "default")], columns=['department_id', 'department']),
                               table_name='departments')

        print(f'done')

    @staticmethod
    def read_raw_ratings_old(movies_df, rating_filter_func=None):
        n_movies = len(movies_df)

        def read_tuples():
            for movie_id in movies_df.id.tolist():
                filename = f'{data_folder_netflix_raw}/download/training_set/mv_{str(movie_id).zfill(7)}.txt'
                if not os.path.exists(filename):
                    print(f'file: {filename} doesnt exist')
                else:
                    if int(movie_id) % 1000 == 0:
                        print(f'Processed {movie_id} / {n_movies} movies')
                    with open(filename, 'r') as fin:
                        for line in fin.readlines()[1:]:
                            items = line.split(',')
                            user_id, rating = int(items[0]), int(items[1])
                            if rating_filter_func is not None and rating_filter_func(rating):
                                yield movie_id, user_id, rating

        return pd.DataFrame(read_tuples(), columns=['movie_id', 'user_id', 'rating'])

    @staticmethod
    def read_raw_ratings(ml_set_name, ml_set):

        assert ml_set_name.startswith("ml-"), f"use movielens set name like: 'ml-100k', 'ml-1m'"

        header = 0 if 'ignore_header' in ml_set and ml_set['ignore_header'] else None

        with zipfile.ZipFile(f"{data_folder_movielens_raw}/{ml_set_name}.zip") as z:
            with z.open(f"{ml_set['ratings_path']}") as f:
                df = pd.read_csv(f, header=header, delimiter=ml_set['ratings_delimiter'], names=[
                    'user_id', 'movie_id', 'rating', 'timestamp'
                ])

        return df[['movie_id', 'user_id', 'rating']][df.rating > 3]

    @staticmethod
    def read_raw_movies(ml_set_name, ml_set):

        assert ml_set_name.startswith("ml-"), f"use movielens set name like: 'ml-100k', 'ml-1m'"

        header = 0 if 'ignore_header' in ml_set and ml_set['ignore_header'] else None

        with zipfile.ZipFile(f"{data_folder_movielens_raw}/{ml_set_name}.zip") as z:
            with z.open(f"{ml_set['movies_path']}") as f:
                df = pd.read_csv(f, header=header, delimiter=ml_set['movies_delimiter'], encoding="ISO-8859-1",
                                 names=ml_set['movies_header'])

        # we choose the first genre as the main one
        df['main_genre'] = df.tags.apply(lambda x: x.split('|')[0])

        return df[['id', 'title', 'main_genre']]
