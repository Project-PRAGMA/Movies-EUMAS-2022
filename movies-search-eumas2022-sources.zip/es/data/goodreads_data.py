import pandas as pd

from es.data_config import data_folder_goodreads_raw
from es.data.base_data import BaseData


class GoodreadsData(BaseData):
    def __init__(self, parquet_folder):
        super().__init__(parquet_folder)

    # INTERFACE =========================

    def read_df_products(self):
        df = self.df_folder.read_df('products')
        df['product_name'] = df.product_name.apply(lambda x: x.strip() if x is not None else None)
        return df

    def read_df_orders(self):
        return self.df_folder.read_df('orders')

    def read_df_order_products__all(self):
        return self.df_folder.read_df('order_products__all')

    def read_df_departments(self):
        return self.df_folder.read_df('departments')

    def read_df_aisles(self):
        return self.df_folder.read_df('aisles')

    def read_df_product_distances(self):
        raise NotImplemented

    def product_distances_filepath(self):
        raise NotImplemented

    # IMPLEMENTATION =========================

    def convert_raw2parquet(self):
        import zipfile
        with zipfile.ZipFile(f"{data_folder_goodreads_raw}/goodbooks-10k.zip") as z:

            with z.open("ratings.csv") as f:
                df_ratings = pd.read_csv(f)
            with z.open("books.csv") as f:
                df_books = pd.read_csv(f)

        products_df = df_books[['book_id', 'original_title']]
        products_df.columns = ['product_id', 'product_name']

        order_products_df = df_ratings.query("rating>3")[['user_id', 'book_id']]
        order_products_df.columns = ['order_id', 'product_id']

        products_df['main_genre'] = 'NA'
        products_df['aisle_id'] = 1
        products_df['department_id'] = 1
        self.df_folder.save_df(df=products_df, table_name='products')

        print(f'!!!!!!!!!!!!!!!!!!!!!   count of ratings: {len(df_ratings)}')
        self.df_folder.save_df(df=order_products_df, table_name='order_products__all')

        order_df = pd.DataFrame(order_products_df.order_id.unique(), columns=['order_id'])
        order_df['user_id'] = order_df.order_id
        self.df_folder.save_df(df=order_df, table_name='orders')

        self.df_folder.save_df(df=pd.DataFrame([(1, "default")], columns=['aisle_id', 'aisle']), table_name='aisles')

        self.df_folder.save_df(df=pd.DataFrame([(1, "default")], columns=['department_id', 'department']),
                               table_name='departments')

        print(f'done')
