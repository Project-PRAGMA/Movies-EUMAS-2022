
import random

import pandas as pd

from es.data.base_data import Product, Aisle, Department, Order, OrderProduct
from es.utils import RandFreq


# aisles are named by product categories
# products are: grade x material x category

class SyntheticData:
    def __init__(self, order_count, products_per_order_limits=(9, 11), product_type_weights=None):
        self.order_count = order_count
        self.products_per_order_limits = products_per_order_limits

        self.grades = list(self.gen_grades())
        self.materials = list(self.gen_materials())
        self.product_types = list(self.gen_product_types())

        self.rand_product_types = RandFreq.create_linear(
            len(self.product_types)) if product_type_weights is None else RandFreq(product_type_weights)

        self.aisles = list(self.gen_aisles())
        self.aisle_df = pd.DataFrame(self.aisles, columns='aisle_id,aisle'.split(','))

        self.departments = list(self.gen_departments())
        self.department_df = pd.DataFrame(self.departments, columns='department_id,department'.split(','))

        self.orders = list(self.gen_orders())
        self.order_df = pd.DataFrame(self.orders, columns=['order_id', 'user_id'])

        self.products = list(self.gen_products())
        self.product_by_name = {p.name: p for p in self.products}
        self.product_df = pd.DataFrame(self.products,
                                       columns="product_id,product_name,aisle_id,department_id".split(','))

        self.order_products_all_df = pd.DataFrame(self.gen_order_products(self.products_per_order_limits),
                                                  columns="order_id,product_id".split(','))

    def gen_order_products(self, product_per_order_limits):
        for order in self.orders:
            items_in_order = range(random.randint(product_per_order_limits[0], product_per_order_limits[1]))

            for _ in items_in_order:
                grade = random.choice(self.grades)
                material = random.choice(self.materials)
                product_type = self.rand_product_types.choice(self.product_types)

                yield OrderProduct(
                    order_id=order.id,
                    product_id=self.product_by_name[self.gen_product_name(grade, material, product_type)].id)

    def gen_orders(self):
        for order_id in range(1, self.order_count + 1):
            yield Order(id=order_id, user_id=1)

    def gen_aisles(self):
        id = 0
        for category in self.gen_product_types():
            id += 1
            yield Aisle(id=id, name=category)

    def gen_departments(self):
        return [Department(id=1, name="Fishing")]

    def gen_products(self):
        id = 0
        for department in self.departments:
            for aisle in self.aisles:
                for material in self.gen_materials():
                    for grade in self.gen_grades():
                        id += 1
                        product = aisle.name
                        yield (Product(id=id, name=self.gen_product_name(grade, material, product), aisle_id=aisle.id,
                                       department_id=department.id))

    @staticmethod
    def gen_product_name(grade, material, product):
        return f"{grade} {material} {product}"

    def gen_product_types(self):
        return 'line,reel,holder,rod,wrap,carrier,buouy'.split(',')

    def gen_materials(self):
        return 'steel,alu,nylon'.split(',')

    def gen_grades(self):
        return 'standard,premium,luxury'.split(',')

    ### data interface

    def read_df_products(self):
        return self.product_df

    def read_df_orders(self):
        return self.order_df

    def read_df_order_products__all(self):
        return self.order_products_all_df

    def read_df_departments(self):
        return self.department_df

    def read_df_aisles(self):
        return self.aisle_df
