import io
import os
import zipfile

import pandas as pd

from es.data_config import data_folder_netflix_raw
from es.data.base_data import BaseData


class NetflixData(BaseData):
    def __init__(self, parquet_folder):
        super().__init__(parquet_folder)

    # INTERFACE =========================

    def read_df_products(self):
        return self.df_folder.read_df('products')

    def read_df_orders(self):
        return self.df_folder.read_df('orders')

    def read_df_order_products__all(self):
        return self.df_folder.read_df('order_products__all')

    def read_df_departments(self):
        return self.df_folder.read_df('departments')

    def read_df_aisles(self):
        return self.df_folder.read_df('aisles')

    def read_df_product_distances(self):
        raise NotImplemented

    def product_distances_filepath(self):
        raise NotImplemented

    # IMPLEMENTATION =========================

    def convert_raw2parquet(self, n_movies=1000000):
        movies_df = NetflixData.read_raw_movies()
        products_df = movies_df[['id', 'title']]
        products_df.columns = ['product_id', 'product_name']
        products_df['aisle_id'] = 1
        products_df['department_id'] = 1
        self.df_folder.save_df(df = products_df, table_name='products')

        ratings_df = NetflixData.read_raw_ratings(n_movies, rating_filter_func=lambda rating: rating > 3)
        print(f'!!!!!!!!!!!!!!!!!!!!!   count of ratings: {len(ratings_df)}')
        order_products_df = ratings_df[['user_id', 'movie_id']]
        order_products_df.columns=['order_id', 'product_id']
        self.df_folder.save_df(df = order_products_df, table_name='order_products__all')

        order_df = pd.DataFrame(order_products_df.order_id.unique(), columns=['order_id'])
        order_df['user_id'] = order_df.order_id
        self.df_folder.save_df(df = order_df, table_name='orders')

        self.df_folder.save_df(df = pd.DataFrame([(1, "default")], columns=['aisle_id', 'aisle']), table_name='aisles')

        self.df_folder.save_df(df = pd.DataFrame([(1, "default")], columns=['department_id', 'department']), table_name='departments')

        print(f'done')


    @staticmethod
    def read_raw_ratings_old(movies_df, rating_filter_func=None):
        n_movies = len(movies_df)

        def read_tuples():
            for movie_id in movies_df.id.tolist():
                filename = f'{data_folder_netflix_raw}/download/training_set/mv_{str(movie_id).zfill(7)}.txt'
                if not os.path.exists(filename):
                    print(f'file: {filename} doesnt exist')
                else:
                    if int(movie_id) % 1000 == 0:
                        print(f'Processed {movie_id} / {n_movies} movies')
                    with open(filename, 'r') as fin:
                        for line in fin.readlines()[1:]:
                            items = line.split(',')
                            user_id, rating = int(items[0]), int(items[1])
                            if rating_filter_func is not None and rating_filter_func(rating):
                                yield movie_id, user_id, rating

        return pd.DataFrame(read_tuples(), columns=['movie_id', 'user_id', 'rating'])

    @staticmethod
    def read_raw_ratings(n_movies, rating_filter_func=None):

        def read_tuples():
            processed = 0
            with zipfile.ZipFile(f'{data_folder_netflix_raw}/netflix-prize-data.zip') as zf:
                for i in range (1, 5):
                    filename = f'combined_data_{i}.txt'
                    with io.TextIOWrapper(zf.open(filename), encoding='ISO-8859-1') as f:
                        print(f'processing {filename}')
                        # 1:
                        # 1488844,3,2005-09-06

                        movie_id = None
                        for line in f.readlines():
                            if ':' in line:
                                if processed >= n_movies:
                                    break
                                movie_id = int(line[:-2])
                                processed += 1
                                if processed % 10 == 0:
                                    print(f'processed {processed} movies out of {n_movies}')
                                continue

                            items = line.split(',')
                            user_id, rating = int(items[0]), int(items[1])

                            if rating_filter_func is not None and rating_filter_func(rating):
                                yield movie_id, user_id, rating

        return pd.DataFrame(read_tuples(), columns=['movie_id', 'user_id', 'rating'])

    @staticmethod
    def read_raw_movies():
        def movie_tuples():
            with zipfile.ZipFile(f'{data_folder_netflix_raw}/netflix-prize-data.zip') as zf:
                with io.TextIOWrapper(zf.open('movie_titles.csv'), encoding='ISO-8859-1') as f:
                    for line in f.readlines():
                        items = line[:-1].split(',')
                        yield int(items[0]), items[1], ','.join(items[2:])

        return pd.DataFrame(movie_tuples(), columns=['id', 'year', 'title'])
