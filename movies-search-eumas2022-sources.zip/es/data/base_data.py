import os
from collections import namedtuple
import pyarrow as pa
from pyarrow import parquet as pq

Product = namedtuple("Product", "id name aisle_id department_id")
Aisle = namedtuple("Aisle", "id name")
Department = namedtuple("Department", "id name")
Order = namedtuple("Order", 'id user_id')
OrderProduct = namedtuple("OrderProduct", 'order_id product_id')


class ParquetDFFolder:
    def __init__(self, data_folder, verbose=1):
        self.verbose = verbose
        self.data_folder = data_folder
        if not os.path.exists(data_folder):
            print(f'creating the parquet data folder: {data_folder}')
            os.makedirs(data_folder)

    def path_to_parquet(self, table_name):
        return self.data_folder + '/' + table_name + '.parquet'

    def read_df(self, table_name):
        filepath = self.path_to_parquet(table_name)
        if self.verbose>0:
            print(f'reading DataFrame {table_name} from parquet: {filepath}')
        df = pq.read_table(self.path_to_parquet(table_name)).to_pandas()
        if self.verbose>0:
            print(f'{table_name} contains {len(df)} items')
        return df

    def save_df(self, df, table_name):
        filepath = self.path_to_parquet(table_name)
        if self.verbose>0:
            print(f'saving DataFrame as Parquet to: {filepath}')
        table = pa.Table.from_pandas(df)
        pq.write_table(table, filepath)


class BaseData(object):
    def __init__(self, data_folder, verbose=1):
        self.verbose = verbose
        self.df_folder = ParquetDFFolder(data_folder, verbose)
        self.tables = ['aisles', 'departments', 'order_products__prior', 'order_products__all', 'order_products__train',
                       'orders', 'products']
