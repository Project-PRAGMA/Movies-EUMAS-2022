from typing import List, Dict

from es.OwaGreedy1 import OwaGreedy1


class OwaGreedy2(OwaGreedy1):
    def __init__(self, m, k, pref_profile: List[Dict[int, float]], owa_vector: List[float], verbose=0):
        """
        g2 - don't recalculate the previous voter score - cache it instead
        """
        OwaGreedy1.__init__(self, m=m, k=k, pref_profile=pref_profile, owa_vector=owa_vector, verbose=verbose)
        self.prev_voter_scores_by_voter_index = {}

    def run(self):
        committee = []  # we use a list to make sure the order is preserved
        committee_score = 0
        for member_ix in range(self.k):
            max_score = -1
            max_score_rix = -1
            max_updated_scores = {}
            for rix in range(self.m):
                if rix not in committee:
                    score, updated_voter_scores = self.score(committee, rix, committee_score)
                    if score > max_score:
                        max_score_rix, max_score, max_updated_scores = rix, score, updated_voter_scores
            committee.append(max_score_rix)
            committee_score = max_score
            for voter_ix, voter_score in max_updated_scores.items():
                self.prev_voter_scores_by_voter_index[voter_ix] = voter_score
            if self.verbose > 0:
                print(f"added member #{member_ix}: {max_score_rix}, total committee score {max_score}")
        return committee, committee_score

    def score(self, committee, rix_added, committee_score):
        new_committee = committee + [rix_added]
        old_resource_score = 0.0
        new_resource_score = 0.0
        updated_voter_scores = {}
        for voter in self.get_voters_approving_resource(rix_added):
            old_voter_score = (self.prev_voter_scores_by_voter_index[voter.index]
                                if voter.index in self.prev_voter_scores_by_voter_index
                                else self.get_voter_score(committee, voter))
            new_voter_score = self.get_voter_score(new_committee, voter)

            old_resource_score += old_voter_score
            new_resource_score += new_voter_score

            updated_voter_scores[voter.index] = new_voter_score

        committee_score = committee_score - old_resource_score + new_resource_score
        return committee_score, updated_voter_scores
