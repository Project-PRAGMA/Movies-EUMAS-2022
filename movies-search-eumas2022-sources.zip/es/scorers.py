import numpy as np


class BaseScorer:
    def score(self, order_id, product_id):
        pass


class CachingScorer(BaseScorer):
    def __init__(self, batched_scorer):
        self.batched_scorer: BatchedUtilityScorer = batched_scorer
        self.cached_orders = {}

    def score(self, order_id, product_id):
        if order_id not in self.cached_orders:
            self.cached_orders[order_id] = self.batched_scorer.score_order(order_id)
        return self.cached_orders[order_id][product_id]

    def __str__(self):
        return f"{self.batched_scorer}"


class BatchedUtilityScorer:
    """
    Applies utilities based on the order of products according to the given metric.
    `scoring_strategy` defines the actual utility values per rank of the product in order's preferences
    """

    def __init__(self, found_df_no_search_ids, metric, ascending, scoring_strategy, approval_set_func):
        self.approval_set_func = approval_set_func
        self.scoring_strategy = scoring_strategy
        self.metric = metric
        self.found_df_no_search_ids = found_df_no_search_ids
        self.products_in_metric_order = list(
            found_df_no_search_ids.sort_values(by=metric, ascending=ascending).product_id)

    def score_order(self, order_id):
        return {product_id: self.scoring_strategy.score(ix, product_id)
                for ix, product_id in enumerate(self.get_order_product_ids_in_order(order_id))}

    def get_order_product_ids_in_order(self, order_id):
        order_approvals = self.approval_set_func(order_id)
        order_products_in_order = [x for x in self.products_in_metric_order if x in order_approvals]
        return order_products_in_order

    def __str__(self):
        return f"{self.scoring_strategy}"


class BaseScoringStrategy():
    def score(self, ix, product_id):
        pass


class ProductScoringStrategy(BaseScoringStrategy):
    def __init__(self, product_id2score, name):
        self.name = name
        self.product_id2score = product_id2score
        self.sum = 0
        self.count = 0

    def score(self, ix, product_id):
        if product_id in self.product_id2score:
            return self.product_id2score[product_id]
        else:
            return 0


class AgentSpreadScoringStrategy(ProductScoringStrategy):
    def __init__(self, product_id2score, name=None):
        super().__init__(product_id2score, name if name is not None else '')

    def __str__(self):
        return f"AgentSpread({self.name})"

    @staticmethod
    def from_found_df_sorted_nosearchterm(found_df_sorted_nosearchterm, metric='tfidfto2'):
        df = found_df_sorted_nosearchterm.copy()
        df['direct_score'] = df[metric] / df.order_count_found
        pid2score = {x.product_id: x.direct_score for x in df.itertuples()}
        return AgentSpreadScoringStrategy(pid2score, name=metric)


class AgentSpreadSqrtScoringStrategy(ProductScoringStrategy):
    def __init__(self, product_id2score, name=None):
        super().__init__(product_id2score, name if name is not None else '')

    def __str__(self):
        return f"AgentSpreadSqrt({self.name})"

    @staticmethod
    def from_found_df_sorted_nosearchterm(found_df_sorted_nosearchterm, metric='tfidfto2'):
        df = found_df_sorted_nosearchterm.copy()
        df['direct_score'] = np.sqrt(df[metric] / df.order_count_found)
        pid2score = {x.product_id: x.direct_score for x in df.itertuples()}
        return AgentSpreadSqrtScoringStrategy(pid2score, name=metric)


class AgentCountSqrtSpreadScoringStrategy(ProductScoringStrategy):
    def __init__(self, product_id2score, name=None):
        super().__init__(product_id2score, name if name is not None else '')

    def __str__(self):
        return f"AgentCountSqrtSpread({self.name})"

    @staticmethod
    def from_found_df_sorted_nosearchterm(found_df_sorted_nosearchterm, metric='tfidfto2'):
        df = found_df_sorted_nosearchterm.copy()
        df['direct_score'] = df[metric] / np.sqrt(df.order_count_found)
        pid2score = {x.product_id: x.direct_score for x in df.itertuples()}
        return AgentCountSqrtSpreadScoringStrategy(pid2score, name=metric)


class AgentSqrtSpreadScoringStrategy(ProductScoringStrategy):
    def __init__(self, product_id2score, name=None):
        super().__init__(product_id2score, name if name is not None else '')

    def __str__(self):
        return f"AgentSqrtSpread({self.name})"

    @staticmethod
    def from_found_df_sorted_nosearchterm(found_df_sorted_nosearchterm, metric='tfidfto2'):
        df = found_df_sorted_nosearchterm.copy()
        df['direct_score'] = np.sqrt(df[metric]) / df.order_count_found
        pid2score = {x.product_id: x.direct_score for x in df.itertuples()}
        return AgentSqrtSpreadScoringStrategy(pid2score, name=metric)


class DirectSqrtScoringStrategy(ProductScoringStrategy):
    def __init__(self, product_id2score, name=None):
        super().__init__(product_id2score, name if name is not None else '')

    def __str__(self):
        return f"DirectSqrt({self.name})"

    @staticmethod
    def from_found_df_sorted_nosearchterm(found_df_sorted_nosearchterm, metric='tfidfto2'):
        df = found_df_sorted_nosearchterm.copy()
        df['direct_score'] = np.sqrt(df[metric])
        pid2score = {x.product_id: x.direct_score for x in df.itertuples()}
        return DirectSqrtScoringStrategy(pid2score, name=metric)


class DirectScoringStrategy(ProductScoringStrategy):
    def __init__(self, product_id2score, name=None):
        super().__init__(product_id2score, name if name is not None else '')

    def __str__(self):
        return f"Direct({self.name})"

    @staticmethod
    def from_found_df_sorted_nosearchterm(found_df_sorted_nosearchterm, metric='tfidfto2'):
        df = found_df_sorted_nosearchterm.copy()
        df['direct_score'] = df[metric]
        pid2score = {x.product_id: x.direct_score for x in df.itertuples()}
        return DirectScoringStrategy(pid2score, name=metric)


class BordaTopnScoringStrategy(BaseScoringStrategy):
    def __init__(self, topn, m):
        self.m = m
        self.topn = topn

    def score(self, ix, product_id):
        return self.m - ix - 1 if ix < self.topn else 0

    def __str__(self):
        return f'BordaTopn(topn={self.topn})'


class MTopnScoringStrategy(BaseScoringStrategy):
    def __init__(self, topn, m):
        self.m = m
        self.topn = topn

    def score(self, ix, product_id):
        return self.topn - ix - 1 if ix < self.topn else 0

    def __str__(self):
        return f'MTopn(topn={self.topn})'


class TopnScoringStrategy(BaseScoringStrategy):
    def __init__(self, topn):
        self.topn = topn

    def score(self, ix, product_id):
        return max(self.topn - ix, 0)

    def __str__(self):
        return f'Topn(topn={self.topn})'


class InverseScoringStrategy(BaseScoringStrategy):
    def __init__(self, exponent=1.0):
        self.exponent = exponent

    def score(self, ix, product_id):
        return 1 / (ix + 1) ** self.exponent

    def __str__(self):
        return f'Inverse(exponent={self.exponent})'


class TopnInverseScoringStrategy(BaseScoringStrategy):
    def __init__(self, topn, exponent=1.0):
        self.topn = topn
        self.exponent = exponent

    def score(self, ix, product_id):
        return 1 / (ix + 1) ** self.exponent if ix < self.topn else 0

    def __str__(self):
        return f'TopnInverse(topn={self.topn}, exponent={self.exponent})'


class CustomScoringStrategy(BaseScoringStrategy):
    def __init__(self, name, func_ix_id):
        self.name = name
        self.func_ix_id = func_ix_id

    def score(self, ix, product_id):
        return self.func_ix_id(ix, product_id)

    def __str__(self):
        return f'SS:{self.name}'


def custom_scoring_strategy(name, func_ix_id):
    return lambda _: CustomScoringStrategy(name, func_ix_id)
