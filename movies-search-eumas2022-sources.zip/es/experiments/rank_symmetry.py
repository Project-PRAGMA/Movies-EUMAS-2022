import math
import os
from pathlib import Path

import numpy as np
import pandas as pd
import seaborn as sns
from IPython.core.display import display
from pandasql import sqldf

from es.data.movielens_data import MovielensData
from es.data_config import data_movielens_25m
from es.elections import InstacartDataFrames
from es.electionutils import ElectionUtils
from es.utils import search_term2re, convert_rule4paper
from sql_database import Database

sql = lambda q: sqldf(q, globals(), 'sqlite:///:memory:')
sqllocal = lambda q, env: sqldf(q, env, 'sqlite:///:memory:')


def get_out_folder(target):
    return f"../../out/{target}/rank_symmetry"


def rank_symmetry(target, input_dir):
    import os
    from tqdm import tqdm
    out_dir = get_out_folder(target)

    if not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=False)

    folders = [f for f in os.listdir(input_dir) if os.path.exists(f"{input_dir}/{f}/cache.db")]

    summary_df = None
    for exp_name in folders:
        exp_path = f"../../out/{target}/distances-movielens/{exp_name}/cache.db"
        print(f"Loading: {exp_path}")
        db = Database(exp_path)
        # db.get_tables()
        p2p_ranks = db.query("select * from p2p_ranks")
        # p2p_ranks
        p2p_ranks['rank_diff'] = np.abs(p2p_ranks.rank_1_2 - p2p_ranks.rank_2_1)
        p2p_ranks['index'] = p2p_ranks.index

        f = sns.relplot(data=p2p_ranks, x="index", y="rank_diff", kind='scatter', size=.5, aspect=2)
        f.savefig(f'{out_dir}/rank_diffs-{exp_name}-by-index.png')
        g = sns.displot(data=p2p_ranks, x="rank_diff", kind='hist', aspect=2)
        g.savefig(f'{out_dir}/rank_diffs-{exp_name}-distribution.png')
        diff_df = p2p_ranks[['rank_diff']].describe()
        diff_df.columns = [exp_name]
        if summary_df is None:
            summary_df = diff_df
        else:
            summary_df = pd.concat([summary_df, diff_df], axis=1)

    print(f"Saved results to: {out_dir}")


if __name__ == "__main__":
    target = 'prod'
    rank_symmetry(
        target=target,
        results_dir=f"../../out/{target}/distances-movielens"
    )

    pass
