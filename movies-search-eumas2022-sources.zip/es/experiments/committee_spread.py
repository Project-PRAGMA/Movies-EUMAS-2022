import bz2
import math
import os
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
import seaborn as sns
from IPython.core.display import display
from pandasql import sqldf

from es.data.movielens_data import MovielensData
from es.data_config import data_movielens_25m
from es.elections import InstacartDataFrames
from es.electionutils import ElectionUtils
from es.utils import search_term2re, convert_rule4paper, unique
from sql_database import Database
import os
from tqdm import tqdm

sql = lambda q: sqldf(q, globals(), 'sqlite:///:memory:')
sqllocal = lambda q, env: sqldf(q, env, 'sqlite:///:memory:')


def get_out_folder(target):
    return f"../../out/{target}/committee_spread"


def committee_spread(target, algo_quality_results_dir):
    committee_spread_positions(algo_quality_results_dir, target)
    committee_spread_p2p(target, algo_quality_results_dir)

    visualise(target)


def committee_spread_positions(algo_quality_results_dir, target):
    out_dir = get_out_folder(target)
    all_winners_path = f"{out_dir}/algo_quality_basic1k_winners.csv.zip"
    if not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=False)
    folders = [f for f in os.listdir(algo_quality_results_dir) if 'w_ix' in f]
    query_rank_diversities_df = None
    all_winners_df = None
    for folder in tqdm(folders, desc='result folders'):
        for winners_path in list(Path(algo_quality_results_dir).joinpath(folder).rglob('exp=*.csv')):
            ranks_path = str(winners_path).replace(".csv", "_TFIDF.tsv")
            # print(f"reading file: {winners_path}, {ranks_path}")
            winners_df = pd.read_csv(winners_path, sep=',')
            ranks_df = pd.read_csv(ranks_path, sep='\t')
            search_id = ranks_df.product_id.tolist()[0]
            search_approvals = ranks_df.order_count.tolist()[0]
            k = winners_df['rank'].max()

            # position 0 is the search product itself
            ranks_df['query_rank'] = range(len(ranks_df))

            huv0_winners_df = ranks_df[['product_id', 'product_name', 'query_rank']][1:k + 1]
            huv0_winners_df.columns = ['product_id', 'product_name', 'rank']
            for column2copy in 'run_name,steps,idf,search_term'.split(','):
                huv0_winners_df[column2copy] = winners_df[column2copy].values[0]
            huv0_winners_df_by_algo = []
            for algo in ['g', 'sa']:
                df = huv0_winners_df.copy()
                df['rule'] = algo + '.HUV_0'
                df['rulex'] = 'HUV_0'
                df['algo'] = algo
                df['algo_version'] = 4 if algo == 'g' else 2
                huv0_winners_df_by_algo.append(df)

            winners_df = pd.concat([winners_df] + huv0_winners_df_by_algo)

            merged_df = winners_df.merge(ranks_df, on='product_id')
            merged_df['search_id'] = search_id
            grouped_df = merged_df.groupby(['search_id', 'rulex', 'algo'], as_index=False).mean()[
                ['search_id', 'rulex', 'algo', 'query_rank']
            ]
            grouped_df['search_approvals'] = search_approvals
            grouped_df['rule'] = grouped_df.rulex
            grouped_df = grouped_df[['search_id', 'search_approvals', 'rule', 'algo', 'query_rank']]

            query_rank_diversities_df = grouped_df if query_rank_diversities_df is None else pd.concat(
                [query_rank_diversities_df, grouped_df])

            winners_df['rule'] = winners_df.rulex
            winners_df = winners_df[['rule', 'algo', 'search_term', 'rank', 'product_id']]
            winners_df['search_id'] = search_id
            winners_df['search_approvals'] = search_approvals

            winners_df = winners_df[
                ['search_term', 'search_id', 'search_approvals', 'rule', 'algo', 'rank', 'product_id']]
            all_winners_df = winners_df if all_winners_df is None else pd.concat([all_winners_df, winners_df])

    all_winners_df.to_csv(all_winners_path, index=False, compression='zip')

    query_rank_diversities_df['algo'] = query_rank_diversities_df['algo'].apply(
        lambda x: 'Greedy' if x == 'g' else 'SA')
    query_rank_diversities_df.to_csv(f"{out_dir}/query-rank-diversities.csv", index=False)


def committee_spread_p2p(target, algo_quality_results_dir, limit_commmittee_count=None):
    out_dir = get_out_folder(target)

    all_winners_path = f"{out_dir}/algo_quality_basic1k_winners.csv.zip"
    all_tfidfs_path = f"{out_dir}/algo_quality_basic1k_winner_metrics.csv.zip"
    p2p_rank_path = f"{out_dir}/algo_quality_basic1k_rank_lookup.pbz2"

    # same as the algo_quality experiment settings
    idata = MovielensData(data_movielens_25m)
    iframes = InstacartDataFrames.from_data(idata, min_popularity=None)
    election_utils = ElectionUtils(iframes)

    print("get all winners from algo_quality basic_1k experiment:    WINNERS(rule,algo,search_id,rank,product_id)")
    all_winners_df = pd.read_csv(all_winners_path, compression='zip')

    print("calculate all winning product metrics:                           dict(search_id -> (id -> rank))")
    if not os.path.exists(p2p_rank_path):
        p2p_rank_dict = {}
        all_winner_metrics_df = None
        count = 0
        for search_id in tqdm(set(all_winners_df.product_id.tolist())):
            count += 1
            # if count % 3000 == 0:
            #     with bz2.BZ2File(f"{p2p_rank_path}_{count}", 'wb') as f:
            #         pickle.dump(p2p_rank_dict, f)

            search_id_dict = {}
            p2p_rank_dict[search_id] = search_id_dict

            tfidf_df = election_utils.calc_found_df(search_df=pd.DataFrame([dict(product_id=search_id)]),
                                                    sorted_by='tfidfto2', verbose=0)
            tfidf_df['search_id'] = search_id
            tfidf_df['rank'] = range(len(tfidf_df))

            for ix, product_id in enumerate(tfidf_df.product_id.tolist()):
                # 0 is the product itself
                search_id_dict[product_id] = ix

            tfidf_df = tfidf_df[['search_id', 'rank', 'product_id']]

            all_winner_metrics_df = tfidf_df if all_winner_metrics_df is None else pd.concat(
                [all_winner_metrics_df, tfidf_df])

        with bz2.BZ2File(p2p_rank_path, 'wb') as f:
            pickle.dump(p2p_rank_dict, f)

        all_winner_metrics_df.to_csv(all_tfidfs_path, index=False, compression='zip')

    p2p_diversities_path = f"{out_dir}/p2p-diversities.csv"
    if not os.path.exists(p2p_diversities_path):

        print("load the lookup table")
        with bz2.BZ2File(p2p_rank_path, 'rb') as f:
            p2p_rank_dict = pickle.load(f)

        # this is super slow:
        # p2p_rank_dict = {}
        # for search_id, group in tqdm(all_winner_metrics_df.groupby(['search_id'])):
        #     search_id_dict = {}
        #     for index, row in group.iterrows():
        #         search_id_dict[row['product_id']] = row['rank']
        #     p2p_rank_dict[search_id] = search_id_dict

        def find_p2p_committee_diversity(winner_ids):
            p2p_rank_sum = 0
            count = 0
            for a in winner_ids:
                for b in winner_ids:
                    if a < b:
                        left = p2p_rank_dict[a][b] if a in p2p_rank_dict and b in p2p_rank_dict[a] else 100000
                        right = p2p_rank_dict[b][a] if b in p2p_rank_dict and a in p2p_rank_dict[b] else 100000
                        p2p_rank_sum += (left + right) / 2
                        count += 1
            return p2p_rank_sum / count

        print("for each election - calculate the winning committee diversity: DIVERSITIES(rule,algo,diversity)")
        committee_diversities = []
        for (rule, algo, search_approvals, search_id), group in all_winners_df.groupby(
                ['rule', 'algo', 'search_approvals', 'search_id']):
            winner_ids = group.product_id.tolist()
            committee_diversities.append(dict(
                rule=rule, algo=algo, search_id=search_id, search_approvals=search_approvals,
                committee_p2p_diversity=find_p2p_committee_diversity(winner_ids)))

        comm_div_df = pd.DataFrame(committee_diversities)

        print("take avg/std across all the committees by algo, rule")
        pysqldf = lambda q, df: sqldf(q, dict(tmp=df))
        df = pysqldf(
            "select rule, algo, search_id, search_approvals, avg(committee_p2p_diversity) as p2p_diversity from tmp group by rule, algo, search_id, search_approvals",
            comm_div_df)
        df['algo'] = df['algo'].apply(lambda x: 'Greedy' if x == 'g' else 'SA')
        df.to_csv(p2p_diversities_path, index=False)


def visualise(target):
    visualise_diversity(target, metric_col='query_rank', codename='query-rank-diversities')
    visualise_diversity(target, metric_col='p2p_diversity', codename='p2p-diversities')


def visualise_diversity(target, metric_col, codename):
    out_dir = get_out_folder(target)

    rule_algo_approvals_metric_df = pd.read_csv(f"{out_dir}/{codename}.csv")

    rule_algo_approvals_metric_df['rule'] = rule_algo_approvals_metric_df.rule.apply(lambda x: convert_rule4paper(x))

    rule_algo_approvals_metric_df['approvals'] = rule_algo_approvals_metric_df.search_approvals.apply(
        lambda x: np.power(10, math.ceil(np.log10(x))))

    stats_df = rule_algo_approvals_metric_df.groupby('rule,algo,approvals'.split(','), as_index=False).agg(
        {metric_col: ['mean', 'std', 'count']})
    stats_df.columns = ['rule', 'algo', 'approvals', 'average', 'std', 'movie count']

    sns.set_theme(style="whitegrid", palette="bright", font_scale=1, context='notebook')

    f = sns.catplot(kind='point', data=rule_algo_approvals_metric_df, y=metric_col, x='rule', hue='algo', dodge=.05,
                    ci='sd')
    sns.despine(left=True, bottom=True)
    f.savefig(f"{out_dir}/{codename}.png", dpi=300)

    unique_approvals = len(unique(rule_algo_approvals_metric_df['approvals'].tolist()))
    approvals_palette = sns.cubehelix_palette(dark=.2, light=.9, n_colors=unique_approvals)
    f = sns.catplot(kind='point', data=stats_df, y='std', x='rule', hue='approvals', col='algo',
                    palette=approvals_palette, aspect=.5,
                    )
    sns.despine(left=True, bottom=True)
    f.savefig(f"{out_dir}/{codename}-std.png", dpi=300)

    f = sns.catplot(kind='point', data=stats_df, y='average', x='rule', hue='approvals', col='algo',
                    palette=approvals_palette, aspect=.5,
                    )
    sns.despine(left=True, bottom=True)
    f.savefig(f"{out_dir}/{codename}-average.png", dpi=300)

    f = sns.catplot(kind='bar', data=stats_df.query("algo=='Greedy' and rule=='$1$-HUV'"),
                    y='movie count', x='approvals', palette=approvals_palette
                    )
    sns.despine(left=True, bottom=True)
    f.savefig(f"{out_dir}/{codename}-count.png", dpi=300)

    # f = sns.displot(kind='hist', data=mean_positions_df.query("algo=='Greedy' and rule=='$1$-HUV'"), x='approvals')
    # sns.despine(left=True, bottom=True)
    # f.savefig(f"{out_dir}/{codename}-count.png", dpi=300)
    #
    f = sns.catplot(kind='strip', data=rule_algo_approvals_metric_df, y=metric_col, x='rule', col='algo',
                    hue='approvals',
                    palette=approvals_palette
                    )
    sns.despine(left=True, bottom=True)
    f.savefig(f"{out_dir}/{codename}-strip.png", dpi=300)

    print(f"Saved results to: {out_dir}")


def visualise_distances_exp(dist_exp_folder):
    db = Database(dist_exp_folder)

    df = db.query(f"""
    select *
    from winners w inner join p2p_ranks r on w.search_product_id=r.id1 and w.product_id=id2
    """)
    display(df[:30])
    sns.catplot(data=df, kind='point', x='rule', y='avg_rank', col='search_term', ci=95, dodge=0.2)


if __name__ == "__main__":
    target = 'prod'

    committee_spread_positions(
        target=target,
        algo_quality_results_dir=f"../../out/prod/algo_quality/basic_1k"
    )

    # committee_spread_p2p(
    #     target=target,
    #     algo_quality_results_dir=f"../../out/prod/algo_quality/basic_1k",
    #     limit_commmittee_count=None
    # )

    # visualise(target)
    # visualise_diversity(target, metric_col='p2p_diversity', codename='p2p-diversities')
    pass
