import argparse
import os

from data_config import data_movielens_25m, data_goodreads_parquet
from elections import ALGO_GREEDY, ALGO_SA, ALGO_ILP
from elections_raw import PrefProfile
from electionutils import ElectionUtils
from es.experiments import algo_performance as algo_performance_exp
from es.experiments import algo_quality as algo_quality_exp
from es.experiments import calibration as calibration_exp
from es.experiments import counting_rradius_raw as counting_rradius_raw_exp
from es.experiments.calibration import calibration
# ARGUMENTS
from experiments import committee_spread, rank_symmetry
from experiments.algo_quality import gen_algo_rules, AQ_ILP, AQ_BASIC_1k, AQ_BASIC, AQ_ILP_sa10k
from experiments.counting_rradius_raw import PERTURB_REMOVE, PERTURB_ADD, PERTURB_SWAP, get_cached_ml_profile_path

# EXPERIMENTS
from utils import MovielensUtils, GoodreadsUtils


def run_experiment(target_run, out_folder, func, rerun=False):
    done_filename = f"{out_folder}/done.done"
    should_run = True
    if not os.path.exists(done_filename):
        status = f"Running a new run"
    elif rerun:
        status = f"Overwriting an existing run"
        os.remove(done_filename)
    else:
        status = f"Skipping - target already exists"
        should_run = False

    print(f"{status}, target: '{target_run}' out_folder: {out_folder}")
    if should_run:
        func()
        with open(done_filename, 'w+') as f:
            f.write('done')


if __name__ == "__main__":

    ap = argparse.ArgumentParser()
    ap.add_argument("-t", "--target", choices=['test', 'prod'], required=True, help="target")
    args = vars(ap.parse_args())
    target = args['target']

    if target == 'prod':

        election_utils = ElectionUtils.from_movielens(data_movielens_25m)
        hot_shots_path = get_cached_ml_profile_path(
            "Hot Shots! .1991.", target, 'movielens', election_utils)
        st_final_frontier_path = get_cached_ml_profile_path(
            "Star Trek V: The Final Frontier .1989.", target, 'movielens', election_utils)
        st_spock_path = get_cached_ml_profile_path(
            "Star Trek III: The Search for Spock .1984.", target, 'movielens', election_utils)
        indiana_temple_path = get_cached_ml_profile_path(
            "Indiana Jones and the Temple of Doom .1984.", target, 'movielens', election_utils)

        for flavour, flavour_params in dict(
                movielens=dict(
                    gen_profile_funcs=[
                        lambda: PrefProfile.from_file(hot_shots_path),
                        lambda: PrefProfile.from_file(st_spock_path),
                        lambda: PrefProfile.from_file(indiana_temple_path),
                    ]),
                generated=dict(
                    gen_profile_funcs=[
                        lambda: PrefProfile.generate_mapel(
                            n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.25, p=0.1),
                        lambda: PrefProfile.generate_mapel(
                            n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.5, p=0.1),
                        lambda: PrefProfile.generate_mapel(
                            n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.75, p=0.1),
                        lambda: PrefProfile.generate_mapel(
                            n_resources=100, n_agents=100, model_id='approval_resampling', phi=1.0, p=0.1),
                        lambda: PrefProfile.generate_mapel(
                            n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.25, p=0.3),
                        lambda: PrefProfile.generate_mapel(
                            n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.5, p=0.3),
                        lambda: PrefProfile.generate_mapel(
                            n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.75, p=0.3),
                        lambda: PrefProfile.generate_mapel(
                            n_resources=100, n_agents=100, model_id='approval_resampling', phi=1.0, p=0.3),
                    ]),
                # generated2=dict(
                #     gen_profile_funcs=[
                #         lambda: PrefProfile.generate_mapel(
                #             n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.25, p=0.2),
                #         lambda: PrefProfile.generate_mapel(
                #             n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.5, p=0.2),
                #         lambda: PrefProfile.generate_mapel(
                #             n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.75, p=0.2),
                #         lambda: PrefProfile.generate_mapel(
                #             n_resources=100, n_agents=100, model_id='approval_resampling', phi=1.0, p=0.2),
                #         lambda: PrefProfile.generate_mapel(
                #             n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.25, p=0.4),
                #         lambda: PrefProfile.generate_mapel(
                #             n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.5, p=0.4),
                #         lambda: PrefProfile.generate_mapel(
                #             n_resources=100, n_agents=100, model_id='approval_resampling', phi=0.75, p=0.4),
                #         lambda: PrefProfile.generate_mapel(
                #             n_resources=100, n_agents=100, model_id='approval_resampling', phi=1.0, p=0.4),
                #     ]),
        ).items():
            run_experiment(target_run=target,
                           rerun=False,
                           out_folder=counting_rradius_raw_exp.get_out_folder(target, flavour),
                           func=lambda: counting_rradius_raw_exp.run_experiment(
                               target=target,
                               flavour=flavour,
                               perturbation_levels=[0.0, 0.01, 0.05, .1, .2, .3, .4, .5, .6, .7, .8, .9, .95],
                               perturbation_types=[PERTURB_ADD, PERTURB_REMOVE],
                               rules=['av', 'pav', 'ccav', 'seqphragmen'],
                               n_elections=200,
                               k=10,
                               gen_profile_funcs=flavour_params['gen_profile_funcs'],
                               seed=13
                           ))

        for flavour, flavour_params in dict(
                startrek=dict(
                    dataset=data_movielens_25m,
                    titles=MovielensUtils.TITLES_STAR_TREK_ALL,
                    ghostfig_titles=MovielensUtils.TITLES_STAR_TREK_ALL
                    # [
                    #     'Star Trek III: The Search for Spock (1984)',  # for GAIW
                    #     'Star Trek: Renegades (2015)'  # for GAIW
                    # ],
                ),
                indiana=dict(
                    dataset=data_movielens_25m,
                    titles=MovielensUtils.TITLES_INDIANA_ALL,
                    ghostfig_titles=MovielensUtils.TITLES_INDIANA_ALL
                ),
                jamesbond=dict(
                    dataset=data_movielens_25m,
                    titles=MovielensUtils.TITLES_JAMES_BOND_ALL,
                    ghostfig_titles=MovielensUtils.TITLES_JAMES_BOND_ALL
                ),
                marvel=dict(
                    titles=MovielensUtils.TITLES_MARVEL_ALL,
                    ghostfig_titles=MovielensUtils.TITLES_MARVEL_ALL,
                    dataset=data_movielens_25m,
                ),

                # dataset_flavour - will be put to folder: calibration_dataset
                gr_potter=dict(
                    titles=GoodreadsUtils.TITLES_POTTER,
                    ghostfig_titles=GoodreadsUtils.TITLES_POTTER,
                    dataset=data_goodreads_parquet
                ),
                gr_anne=dict(
                    titles=GoodreadsUtils.TITLES_ANNE,
                    ghostfig_titles=GoodreadsUtils.TITLES_ANNE,
                    dataset=data_goodreads_parquet
                ),
                gr_five=dict(
                    titles=GoodreadsUtils.TITLES_FIVE,
                    ghostfig_titles=GoodreadsUtils.TITLES_FIVE,
                    dataset=data_goodreads_parquet
                ),
                gr_narnia=dict(
                    titles=GoodreadsUtils.TITLES_NARNIA,
                    ghostfig_titles=GoodreadsUtils.TITLES_NARNIA,
                    dataset=data_goodreads_parquet
                ),
                gr_hunger=dict(
                    titles=GoodreadsUtils.TITLES_HUNGER,
                    ghostfig_titles=GoodreadsUtils.TITLES_HUNGER,
                    dataset=data_goodreads_parquet
                ),
                gr_divergent=dict(
                    titles=GoodreadsUtils.TITLES_DIVERGENT,
                    ghostfig_titles=GoodreadsUtils.TITLES_DIVERGENT,
                    dataset=data_goodreads_parquet
                ),

        ).items():
            run_experiment(target_run=target,
                           rerun=False,
                           out_folder=calibration_exp.get_out_folder(target, flavour),
                           func=lambda: calibration(
                               target=target,
                               flavour=flavour,
                               dataset=flavour_params['dataset'],
                               titles=flavour_params['titles'],
                               ghostfig_titles=flavour_params['ghostfig_titles']
                           ))

        for flavour, algos, search_count, sample_orders, sample_products, k, seed, steps in [
            (AQ_BASIC_1k, [ALGO_GREEDY, ALGO_SA], 1000, None, None, 10, 1451, 50000),
            (AQ_ILP, [ALGO_GREEDY, ALGO_SA, ALGO_ILP], 100, 200, 100, 5, 1451, 1000),
            (AQ_ILP_sa10k, [ALGO_GREEDY, ALGO_SA, ALGO_ILP], 100, 200, 100, 5, 1451, 10000),
        ]:
            run_experiment(target_run=target,
                           rerun=False,
                           out_folder=algo_quality_exp.get_out_folder(target, flavour=flavour),
                           func=lambda: algo_quality_exp.run_algo_quality(
                               target=target,
                               flavour=flavour,
                               process_count=10,
                               search_count=search_count,
                               stop_after_searches=None,
                               min_search_order_count=2,
                               seed=seed,
                               custom_params=dict(
                                   rules=gen_algo_rules(algos=algos, rules=['HUV_1', 'HUV_2', 'HUV_3']),
                                   anneal_settings={'tmax': 9900.0, 'tmin': 0.6, 'steps': steps,
                                                    'updates': 2},
                                   k=k,
                                   filtering=dict(sample_orders=sample_orders, sample_products=sample_products)
                               ))
                           )

        for flavour, algos, iterations_count, titles, custom_params in [
            ('basic', ['g0', 'g1', 'g2', 'g3', 'g3a', 'g4', 'sa0', 'sa1', 'sa2'
                       ], 10,
             [
                 'Star Trek: Renegades (2015)',
                 'Captain Marvel (2018)',
                 'Ant-Man and the Wasp (2018)',
                 'Star Trek V: The Final Frontier (1989)',
                 'Star Trek III: The Search for Spock (1984)',

                 # 'Star Trek: Generations (1994)' - g0 takes at least 2.5h to calc - ignore
             ],
             dict(
                 anneal_settings={'tmax': 9900.0, 'tmin': 0.6, 'steps': 10000,
                                  'updates': 2},
                 k=10,
                 filtering=dict(sample_orders=50000, sample_products=None)
             )),

            ('ilp', ['ilp', 'g'], 10,
             ['Bruce Almighty (2003)',  # 11
              'Who Framed Roger Rabbit? (1988)',  # 23
              'Dark Knight, The (2008)'  # 47
              ],
             dict(
                 k=10,
                 filtering=dict(sample_orders=200, sample_products=200)
             )),
        ]:
            run_experiment(target_run=target,
                           rerun=False,
                           out_folder=algo_performance_exp.get_out_folder(target, flavour),
                           func=lambda: algo_performance_exp.run_algo_performance(
                               target=target,
                               flavour=flavour,
                               iterations_count=iterations_count,
                               algos=algos,
                               rules=['HUV_1'
                                   # , 'HUV_2', 'HUV_3'
                                      ],
                               stop_after_searches=None,
                               seed=1451,
                               titles=titles,
                               custom_params=custom_params)
                           )

        run_experiment(target_run=target,
                       rerun=False,
                       out_folder=committee_spread.get_out_folder(target),
                       func=lambda: committee_spread.committee_spread(
                           target=target,
                           algo_quality_results_dir=f"../../out/{target}/algo_quality/basic_1k"
                       ))

        run_experiment(target_run=target,
                       rerun=False,
                       out_folder=rank_symmetry.get_out_folder(target),
                       func=lambda: rank_symmetry.rank_symmetry(
                           target=target,
                           input_dir=f"../../out/{target}/distances-movielens"
                       ))

    elif target == 'test':

        run_experiment(target_run=target,
                       rerun=True,
                       out_folder=counting_rradius_raw_exp.get_out_folder(target, 'generated'),
                       func=lambda: counting_rradius_raw_exp.run_experiment(
                           target=target,
                           flavour='generated',
                           perturbation_levels=[0.001, 0.01],
                           perturbation_types=[PERTURB_REMOVE, PERTURB_ADD, PERTURB_SWAP],
                           rules=['av', 'pav', 'ccav', 'seqphragmen'],
                           n_elections=10,
                           k=3,
                           gen_profile_funcs=[
                               lambda: PrefProfile.generate_uniform(
                                   n_resources=100,
                                   n_agents=100,
                                   density=.1
                               ),
                               lambda: PrefProfile.generate_uniform(
                                   n_resources=100,
                                   n_agents=100,
                                   density=.2
                               ),
                           ],
                           seed=13
                       ))

        run_experiment(target_run=target,
                       rerun=True,
                       out_folder=calibration_exp.get_out_folder(target, 'startrek'),
                       func=lambda: calibration(
                           target=target,
                           flavour='startrek',
                           titles=[
                               'Star Trek (2009)',
                               'Star Trek: First Contact (1996)'
                           ],
                           ghostfig_titles=[
                               'Star Trek (2009)',
                               'Star Trek: First Contact (1996)'
                           ]
                       ))

        for flavour, algos, search_count, sample_orders, sample_products, k, seed in [
            (AQ_BASIC, [ALGO_GREEDY, ALGO_SA], 100, None, None, 10, 1451),
            (AQ_ILP, [ALGO_GREEDY, ALGO_SA, ALGO_ILP], 100, 30, 50, 3, 1451),
        ]:
            run_experiment(target_run=target,
                           rerun=True,
                           out_folder=algo_quality_exp.get_out_folder(target, flavour=flavour),
                           func=lambda: algo_quality_exp.run_algo_quality(
                               target=target,
                               flavour=flavour,
                               process_count=2,
                               search_count=search_count,
                               stop_after_searches=6,
                               min_search_order_count=2,
                               seed=seed,
                               custom_params=dict(
                                   rules=gen_algo_rules(algos=algos, rules=['HUV_1', 'HUV_2', 'HUV_3']),
                                   anneal_settings={'tmax': 9900.0, 'tmin': 0.6, 'steps': 1000,
                                                    'updates': 2},
                                   k=k,
                                   filtering=dict(sample_orders=sample_orders, sample_products=sample_products)
                               ))
                           )

        run_experiment(target_run=target,
                       rerun=True,
                       out_folder=algo_performance_exp.get_out_folder(target, 'basic'),
                       func=lambda: algo_performance_exp.run_algo_performance(
                           target=target,
                           flavour='basic',
                           iterations_count=2,
                           algos=['g0', 'sa0'],
                           rules=['HUV_3'],
                           stop_after_searches=3,
                           seed=1451,
                           titles=['Star Trek: Renegades (2015)',
                                   # 'Star Trek V: The Final Frontier (1989)',
                                   ],
                           custom_params=dict(
                               anneal_settings={'tmax': 9900.0, 'tmin': 0.6, 'steps': 1000,
                                                'updates': 2},
                               k=3,
                               filtering=dict(sample_orders=None, sample_products=None)
                           ))
                       )

        run_experiment(target_run=target,
                       rerun=False,
                       out_folder=committee_spread.get_out_folder(target),
                       func=lambda: committee_spread.committee_spread(
                           target=target,
                           algo_quality_results_dir=f"../../out/{target}/algo_quality/basic"
                       ))


    else:

        raise Exception(f"Unrecognised target for RUN_EXPERIMENTS: {target}")
