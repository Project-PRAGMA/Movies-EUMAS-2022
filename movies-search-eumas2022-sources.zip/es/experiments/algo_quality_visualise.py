import math
from pathlib import Path

import numpy as np
import pandas as pd
import seaborn as sns
from IPython.core.display import display
from matplotlib import pyplot as plt
from pandasql import sqldf

import data_config
from es.data.movielens_data import MovielensData
from es.data_config import data_movielens_25m
from es.elections import InstacartDataFrames
from es.electionutils import ElectionUtils
from es.utils import search_term2re, convert_rule4paper

sql = lambda q: sqldf(q, globals(), 'sqlite:///:memory:')
sqllocal = lambda q, env: sqldf(q, env, 'sqlite:///:memory:')


def load_run(results_dir):
    import os
    folders = [f for f in os.listdir(results_dir) if 'w_ix' in f]
    committee_scores_df = None

    for folder in folders:
        for scores_file_path in Path(results_dir).joinpath(folder).rglob('committee_scores.tsv'):
            print(f"reading file: {scores_file_path}")
            single_scores_df = pd.read_csv(scores_file_path, sep='\t')
            single_scores_df = single_scores_df
            if committee_scores_df is None:
                committee_scores_df = single_scores_df
            else:
                committee_scores_df = pd.concat([committee_scores_df, single_scores_df])
    if committee_scores_df is None or committee_scores_df.empty:
        print(f"WARNING: There are no results for experiment in: {results_dir}")
        exit(1)
    else:
        committee_scores_df.sort_values(by=['search_term', 'rule'], inplace=True)
    return committee_scores_df


def enrich_with_counts(df_scores, dataset):
    dataset_iframes = InstacartDataFrames.from_data(MovielensData(dataset), min_popularity=None)
    count_df = ElectionUtils(dataset_iframes).product_search
    count_df['product_name_re'] = count_df.product_name.apply(search_term2re)
    scores_with_counts = sqllocal(
        "select s.*, c.order_count from df_scores s join count_df c on s.search_term=c.product_name_re", locals())
    return scores_with_counts


def _generate_scores_aggregated(df_scores, results_dir):
    df_aggregated = df_scores.groupby(['utility_scorer', 'rule']).agg([np.mean, np.std, len])
    display(df_aggregated)
    df_aggregated.to_csv(f"{results_dir}/scores_aggregated.csv")

    tab_rows = []
    cols = []
    for ix, row in df_aggregated.iterrows():
        (utility_scorer, rule) = ix
        cols = [
            ('greedy_to_sa_score', 'mean'), ('greedy_to_sa_score', 'std'),
            ('greedy_to_ilp_score', 'mean'), ('greedy_to_ilp_score', 'std'),
            ('sa_to_ilp_score', 'mean'), ('sa_to_ilp_score', 'std'),
        ]
        cols = [col for col in cols if not math.isnan(row[col])]

        # 1-HUV	&	1.021	&	0.015 \\
        ar = [convert_rule4paper(rule)] + [f"{row[col]:.3f}" for col in cols]
        tab_rows.append(" & ".join(ar) + " \\\\")

    table_latex = (
            "% " + " & ".join([f"{ratio}-{stat}" for ratio, stat in cols]) + "\n"
            + "\n".join(tab_rows)
    )

    with open(f"{results_dir}/scores-aggregated.tex", 'w+') as f:
        f.write(table_latex)


def visualise_algo_quality(target, dataset_path, results_dir, cat_graphs):
    # print('--------', key, ":")
    df = load_run(results_dir)
    print(df.PARAMS[0])
    print(df.PARAMS[0][-100:])
    df['algo_'] = df.rule.apply(lambda x: x[:1])
    df['rule_'] = df.rule.apply(lambda x: x.split('.')[1])
    df_scores = sqllocal(
        "select a.search_term, a.rule_ rule, a.utility_scorer, "
        "   b.committee_score / a.committee_score greedy_to_sa_score, " +
        "   b.committee_score / c.committee_score greedy_to_ilp_score, " +
        "   a.committee_score / c.committee_score sa_to_ilp_score, " +
        "   b.committee_score greedy_score, a.committee_score sa_score, "
        "   c.committee_score ilp_score "
        "from "
        "   df a join df b on a.search_term = b.search_term and a.rule_=b.rule_ and a.utility_scorer=b.utility_scorer "
        "       left outer join df c on a.search_term = c.search_term and a.rule_=c.rule_ and a.utility_scorer=c.utility_scorer and c.algo_='i' " +
        "where a.algo_ = 's' and b.algo_= 'g' "
        " and a.search_term like '%%' "
        " and a.utility_scorer like '%Agent%' "
        " and a.rule_ not like '%HUV_0%'", locals())

    df_scores = enrich_with_counts(df_scores, dataset_path)

    def unique_terms(ts):
        s = set()
        u = []
        for t in ts:
            if t not in s:
                s.add(t)
                u.append(t)
        return u

    term_map = {term: ix for ix, term in enumerate(unique_terms(df_scores.search_term.to_list()))}
    df_scores['iteration'] = df_scores.search_term.apply(lambda term: term_map[term])
    df_scores.to_csv(f"{results_dir}/scores.csv")

    _generate_scores_aggregated(df_scores, results_dir)

    print(f"Saving results to file://{results_dir}")

    df_to_show = df_scores[:]
    df_to_show.loc[:, 'rule'] = df_to_show.rule.apply(lambda x: f"{x[-1]}-HUV")
    generate_plot(cat_graphs, df_to_show, results_dir, size=10, aspect=.75)
    # generate_plot(cat_graphs, df_to_show.query(f"greedy_to_sa_score <= 1.2"), results_dir,
    #               outfile_suffix="-wide", size=10, aspect=1.5)

    # for kind in [
    #     'line',
    #     # 'scatter'
    # ]:
    #     for col in ['greedy_to_ilp_score', 'sa_to_ilp_score', 'greedy_to_sa_score']:
    #         f = sns.relplot(kind=kind, data=df_scores, x='order_count', y=col, hue='rule',
    #                         col='utility_scorer',
    #                         )
    #         f.savefig(f"{results_dir}/fig-{col}-{kind}.png")


def generate_plot(cat_graphs, df_to_show, results_dir, outfile_suffix="", aspect=2.0, size=2, font_scale=1.5):
    stylekwargs = dict(
        # palette='pastel',
        linewidth=.1)

    sns.set_theme(style="whitegrid", palette="bright", font_scale=font_scale, context='notebook')

    for kind in cat_graphs:
        if kind in ['box', 'boxen', 'violin']:
            add_args = dict(
                palette='bright',
                aspect=aspect,
            )
        else:
            add_args = dict(
                hue='order_count',
                palette=sns.cubehelix_palette(n_colors=len(set(df_to_show.order_count)), dark=0, light=.9),
                # alpha=.7,
                legend=False,
                aspect=aspect,
                s=size,
            )

        df_to_show = df_to_show.rename(columns=dict(
            greedy_to_sa_score='greedy/SA',
            sa_to_ilp_score='SA/ILP',
            greedy_to_ilp_score='greedy/ILP'
        ))

        df_melt = df_to_show.melt(
            id_vars=['rule', 'order_count'],
            value_vars=['greedy/SA', 'SA/ILP', 'greedy/ILP']
        )

        f = sns.catplot(kind=kind, data=df_melt, y='value', x='rule',
                        col='variable',
                        height=5,
                        **add_args,
                        **stylekwargs
                        )

        (f.map(plt.axhline, y=1.0, color=".7", dashes=(2, 1), zorder=0)
         .set_axis_labels("rule", "committee score ratio")
         .set_titles("{col_name}")
         .tight_layout(w_pad=2))

        # f.set_ylabels("")
        # f.set_ylabels(label)
        for ax in f.axes.flatten():
            ax.grid(axis='y')
            sns.despine(ax=ax, left=True, bottom=True)

        f.savefig(f"{results_dir}/fig-{kind}{outfile_suffix}.png", dpi=300)


if __name__ == "__main__":
    # target = 'prod'
    # visualise_algo_quality(
    #     target=target,
    #     dataset_path=data_movielens_25m,
    #     # dataset_path=f"../../out/{target}/algo_quality/with_ilp/movielens_25m_o=30_p=40",
    #     results_dir=f"../../out/{target}/algo_quality/basic",
    #     cat_graphs=[
    #         'swarm',
    #         'strip',
    #         # 'box',
    #         # 'boxen',
    #         # 'violin'
    #     ]
    # )
    #

    for target, flavour, sample_orders, sample_products in [
        # ('prod', 'basic_1k', None, None),
        ('prod', 'with_ilp_sa10k', 200, 100),
        ('prod', 'with_ilp', 200, 100)
    ]:
        out_folder = f"../../out/{target}/algo_quality/{flavour}"
        dataset = data_config.data_movielens_25m if sample_orders is None else f"{out_folder}/movielens_25m_o={sample_orders}_p={sample_products}"
        visualise_algo_quality(
            target=target,
            dataset_path=dataset,
            results_dir=out_folder,
            cat_graphs=[
                # 'swarm',
                'strip',
                # 'box',
                # 'boxen',
                # 'violin'
            ]
        )

    pass
