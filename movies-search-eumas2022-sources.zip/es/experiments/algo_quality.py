import multiprocessing
import os
import time
from datetime import datetime

import data_config
import es.elections
from es.electionutils import ElectionUtils
from es.data.movielens_data import MovielensData
from es.elections import InstacartDataFrames
from es.runner.result_inspection import ResultsInspectorSaveCommitteeScores
from es.runner.scenario_runner import ScenarioRunner
from es.scorers import AgentSpreadScoringStrategy
from es.utils import dotdict
from es.utils import search_term2re
from experiments.algo_quality_visualise import visualise_algo_quality

AQ_BASIC = "basic"
AQ_BASIC_1k = "basic_1k"
AQ_ILP = "with_ilp"
AQ_ILP_sa10k = "with_ilp_sa10k"


def get_out_folder(target, flavour):
    return f"../../out/{target}/algo_quality/{flavour}"


def experiment_algo_quality(calc_params, output_base_folder, calc_ix, calc_n, start_ix=0):
    if not os.path.exists(output_base_folder):
        os.makedirs(output_base_folder, exist_ok=False)

    print(f'calculating search terms with ix % {calc_n} == {calc_ix}')
    calc_params.searchterms = [term for ix, term in enumerate(calc_params.searchterms) if ix % calc_n == calc_ix]
    calc_params.searchterms = calc_params.searchterms[start_ix:]

    idata = MovielensData(calc_params["dataset"])
    iframes = InstacartDataFrames.from_data(idata, min_popularity=None)

    print(calc_params)
    start = time.time()
    runner = ScenarioRunner(iframes, calc_params, ResultsInspectorSaveCommitteeScores(f"committee_scores.tsv"))
    exp_folder = runner.run(return_df=False, verbose=0, output_base_folder=output_base_folder,
                            include_unity=False)
    print(exp_folder)
    time_original = time.time() - start

    print(f"TIMING: elections took: {time_original}")

    return exp_folder


def _find_missing(all_search_terms, scores_csv_path):
    import pandas
    # print(all_search_terms)
    done = set(pandas.read_csv(scores_csv_path).search_term) if os.path.exists(scores_csv_path) else set([])
    missing_search_terms = set(all_search_terms) - done
    missing_in_original_order = [term for term in all_search_terms if term in missing_search_terms]
    # print(missing_in_original_order)
    return missing_in_original_order


def gen_algo_rules(algos, rules):
    return [f'{algo}.{r}' for r in rules for algo in algos]


def run_algo_quality(target,
                     flavour,
                     process_count,
                     min_search_order_count,
                     seed,
                     stop_after_searches=None,
                     search_count=100,  # how many searches to run
                     dataset=data_config.data_movielens_25m,
                     custom_params=None,
                     ):
    out_folder = get_out_folder(target, flavour)
    if not os.path.exists(out_folder):
        os.makedirs(out_folder)

    idata = es.data.movielens_data.MovielensData(dataset)
    iframes = es.elections.InstacartDataFrames.from_data(idata)

    sample_orders = custom_params['filtering']['sample_orders']
    sample_products = custom_params['filtering']['sample_products']

    eutils = es.electionutils.ElectionUtils(iframes)
    eligible_products_df = eutils.product_search.query(f"order_count>{min_search_order_count}")

    if sample_orders or sample_products:
        iframes.filter2products(eligible_products_df.product_id, inplace=True)

        # sample new iframes and make the process use it
        iframes.sample(
            n_orders=sample_orders,
            n_products=sample_products,
            random_state=seed,
            inplace=True
        )
        dataset = f"{out_folder}/movielens_25m_o={sample_orders}_p={sample_products}"
        iframes.to_pq(dataset)
        #     disable the filtering down the stream
        custom_params['filtering'] = {}

        eutils = es.electionutils.ElectionUtils(iframes)
        eligible_products_df = eutils.product_search

    print(f"Running ALGO_QUALITY experiment")

    titles_sampled_df = eligible_products_df.sample(n=min(search_count, len(eligible_products_df)), random_state=seed)
    titles_sampled_sorted_df = titles_sampled_df.sort_values('order_count', ascending=True)
    search_terms = [search_term2re(t) for t in
                    titles_sampled_sorted_df.product_name.to_list()]
    if stop_after_searches:
        search_terms = search_terms[:stop_after_searches]
    print(f"Will run {len(search_terms)} searches spread over {process_count} processes")

    search_terms = _find_missing(search_terms, f"{out_folder}/scores.csv")
    # ===========================================================
    PARAMS = dotdict(dict(
        dataset=f"{dataset}",
        # exp_name=f"sa_vs_greedy_{dataset.split('/')[-1]}_{datetime.now().strftime('%Y%m%d-%H%M%S')}",
        exp_name=f"algo_quality_{dataset.split('/')[-1]}",
        k=10,
        searchterms=search_terms,
        scorer_metrics=[
            'tfidfto2',
            # 'bm25'
        ],
        scorer_funcs=[
            AgentSpreadScoringStrategy.from_found_df_sorted_nosearchterm,
        ],
        throw_on_rerun=False  # rerun is fine because we filter the already run searches
    ))

    if custom_params:
        for k, v in custom_params.items():
            PARAMS[k] = v

    class WorkerProcess(multiprocessing.Process):
        def __init__(self, worker_ix, worker_count, output_base_folder, start_ix=None):
            multiprocessing.Process.__init__(self)
            self.start_ix = start_ix if start_ix is not None else 0
            self.worker_count = worker_count
            self.output_base_folder = output_base_folder
            self.worker_ix = worker_ix

        def run(self):
            """
            Run the thread
            """
            print(f'Started worker {self.worker_ix}')
            experiment_algo_quality(PARAMS, self.output_base_folder, self.worker_ix, self.worker_count, self.start_ix)
            print(f'{self.worker_ix}')

    ps = []
    if not os.path.exists(out_folder):
        os.makedirs(out_folder, exist_ok=True)
    for i in range(0, process_count):
        results_worker_folder = f"{out_folder}/w_ix={i}"
        p = WorkerProcess(i, process_count, results_worker_folder)
        ps.append(p)
        p.start()
        # p.run() # runs the worker without starting the process...

    for p in ps:
        p.join()

    visualise_algo_quality(
        target=target,
        dataset_path=dataset,
        results_dir=out_folder,
        cat_graphs=[
            # 'swarm',
            'strip',
            # 'box',
            # 'boxen',
            # 'violin'
        ]
    )
