import time
from typing import List, Dict


class OwaGreedy0(object):
    def __init__(self, m: int, k: int, pref_profile: List[Dict[int, float]],
                 owa_vector: List[float], verbose: int = 0):
        """

        :param m: the count of resources
        :param k: the committee size
        :param pref_profile: a dictionary of resource-0-based-index to utility
        :param owa_vector: owa vector
        :param verbose:
        """
        self.verbose = verbose
        assert pref_profile, "profile must not be empty"
        self.n = len(pref_profile)
        self.m = m
        self.k = k
        assert len(owa_vector) >= self.k, f"owa vector must be longer than k={self.k}"
        self.pref_profile = pref_profile
        self.owa_vector = owa_vector
        self.last_timestamp = time.time()

    # runs the algorithm, returns the winning committee and its score
    def run(self):
        committee = []  # we use a list to make sure the order is preserved
        committee_score = 0
        # add one member at a time
        for new_member_ix in range(self.k):
            max_score, max_score_rix = -1, -1
            # find a new resource with the largest score
            for resource_ix in range(self.m):
                if resource_ix not in committee:
                    resource_score = self.score(committee + [resource_ix])
                    if resource_score > max_score:
                        max_score_rix, max_score = resource_ix, resource_score
            committee.append(max_score_rix)
            committee_score = max_score
            if self.verbose > 0:
                print(f"added member #{new_member_ix}: {max_score_rix}, total committee score {max_score}")
        return committee, committee_score

    # returns the score of the committee
    def score(self, committee: List[int]):
        committee_score = 0
        # add up all the voters' scores
        for voter in self.pref_profile:
            utilities = sorted(
                [voter[cix] for cix in committee if cix in voter],
                reverse=True)
            for utility, owa in zip(utilities, self.owa_vector):
                committee_score += utility * owa
        return committee_score
