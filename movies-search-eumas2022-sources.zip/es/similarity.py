from collections import defaultdict

import pandas as pd
from gensim.models.fasttext import FastText

from es import utils


class SimilarityBase:

    def is_enabled(self):
        return True


class IdentitySimilarity(SimilarityBase):
    def similar_to_id(self, id):
        return [id]

    def is_enabled(self):
        return False


class HardCodedSimilarity(SimilarityBase):
    def __init__(self, similar_name_clusters, df_products):
        self.similar_clusters = similar_name_clusters
        ids_cluster = [[df_products[df_products.product_name == name].product_id.tolist()[0] for name in cluster] for
                       cluster in self.similar_clusters]
        self.similar_lookup = {id: cluster for cluster in ids_cluster for id in cluster}
        print(ids_cluster)
        print(self.similar_lookup)

    def similar_to_id(self, id):
        return self.similar_lookup[id] if id in self.similar_lookup else [id]


class DFWordSimilarity(SimilarityBase):
    def __init__(self, df_products):
        self.df_products = df_products

    def similar_to_id(self, id):
        product_name = self.df_products[self.df_products.product_id == id].product_name.tolist()[0]

        for c in "*(){}[]+.":
            product_name = product_name.replace(c, '')

        words = list(filter(lambda x: x, product_name.split()))
        word_regex = '|'.join(words)

        ret = self.df_products[self.df_products.product_name.str.contains(word_regex)].product_id

        # print(f'words={words}, name={product_name}')

        return ret


class DFAisleSimilarity(SimilarityBase):
    def __init__(self, df_products):
        self.df_products = df_products

    def similar_to_id(self, id):
        aisle_id = self.df_products[self.df_products.product_id == id].aisle_id.tolist()[0]

        return self.df_products[self.df_products.aisle_id == aisle_id].product_id


# TODO: speed up word similarity by pre-calculating distances
class FTWordSimilarity(SimilarityBase):
    def __init__(self, df_products, model_filepath, radius=0.01):
        self.radius = radius
        self.df_products = df_products
        print(f'loading the fastext model...')
        self.model = FastText.load(model_filepath)
        print(f'model loaded.')
        self.cache = defaultdict(list)

    def reset(self, df_products, radius):
        self.cache = defaultdict(list)
        self.df_products = df_products
        self.radius = radius

    def similar_to_id(self, id):

        if not self.cache[id]:
            similars = [id]
            product_name = self.df_products[self.df_products.product_id == id].product_name
            for other_id, other_name in self.df_products[['product_id', 'product_name']].itertuples(index=False):
                if self.model.wv.distance(product_name, other_name) <= self.radius:
                    similars.append(other_id)
            self.cache[id] = similars

        return self.cache[id]


class FTWordSimilarityPreComputed(SimilarityBase):

    def __init__(self, filter_product_ids, instacart_data, radius):
        self.radius = radius
        self.filter_product_ids = filter_product_ids
        self.distances_df = instacart_data.read_df_product_distances()

    def similar_to_id(self, id):
        dist = self.distances_df
        return dist[
            (dist.id1 == id) &
            (dist.distance <= self.radius) &
            (dist.id2.isin(self.filter_product_ids))
            ].id2.sort_values(ascending=True).tolist()

    @staticmethod
    def compute_and_store_all_similarities(instacartFrames, model_filepath, instacartData):

        df_products = instacartFrames.df_products

        print(f'loading the fastext model from {model_filepath}')
        model = FastText.load(model_filepath)

        total_products = len(df_products)
        print(f'computing the distances on {total_products} products')

        def generate_distances():
            count = 0
            for id1, name1 in df_products[['product_id', 'product_name']].itertuples(index=False):
                count += 1
                utils.print_progress(count, total_products, fraction=0.001)
                for id2, name2 in df_products[['product_id', 'product_name']][id1 <= df_products.product_id].itertuples(
                        index=False):
                    yield (id1, id2, model.wv.distance(name1, name2))

        df = pd.DataFrame(generate_distances(), columns=['id1', 'id2', 'distance'])

        print(f'saving distances as Parquet to: {instacartData.product_distances_filepath()}')
        instacartData.save_df(df, instacartData.PRODUCT_DISTANCES)

        return df
