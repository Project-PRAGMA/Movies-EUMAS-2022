import random
import time
from datetime import datetime
from typing import List, Dict

from simanneal import Annealer

from es.algo_utils import build_resource_approving_voters


class OwaAnnealer1(Annealer):

    def __init__(self, m, k, pref_profile: List[Dict[int, float]], owa_vector: List[float], verbose=0):
        self.debug = True
        self.verbose = verbose
        assert pref_profile, "profile must not be empty"
        self.n = len(pref_profile)
        self.m = m
        self.k = k
        assert len(owa_vector) >= self.k, f"owa vector must be longer than k={self.k}"
        self.pref_profile = pref_profile
        self.owa_vector = owa_vector
        self.iterations = 0
        self.last_timestamp = time.time()

        self.resource_ix2approving_voters = build_resource_approving_voters(self.pref_profile, m)
        self.owa_delta = [-x + y for x, y in zip(owa_vector, owa_vector[1:])]
        # NOTE: we assume homogenous utilities for a given resource, hence retrieving from voter 0
        self.rix2voter_ut = {rix: voters[0].approvals[rix]
                             for rix, voters in self.resource_ix2approving_voters.items()}

        # self.copy_strategy = "deepcopy"
        state = random.sample(list(range(self.m)), k)
        print(f'first state= {sorted(state)}')
        state = [rix for _, rix in
                 sorted(
                     ((self.rix2voter_ut[rix], rix) for rix in state),
                     reverse=True)
                 ]
        assert len(state) == self.k, f"state must be of len {self.k}"
        super().__init__(state)

    def run(self, settings=None):
        default_minutes = 5
        # anneal_settings = {'tmax': 8100.0, 'tmin': 2.6, 'steps': 20000, 'updates': 100}
        if not settings:
            print(f"estimating anneal settings to target: {default_minutes} "
                  f"minutes calculation time @ {datetime.now().strftime('%H:%M:%S')}")
            settings = self.auto(minutes=default_minutes)
        elif 'minutes' in settings:
            print(f"estimating anneal settings to target: {settings['minutes']} "
                  f"minutes calculation time "
                  f"@ {datetime.now().strftime('%H:%M:%S')}")
            settings = self.auto(minutes=settings['minutes'])

        print(f"annealing with: {settings}"
              f"@ {datetime.now().strftime('%H:%M:%S')}")
        self.set_schedule(settings)
        self.copy_strategy = "slice"
        committee, energy = self.anneal()

        print(f"annealing done "
              f"@ {datetime.now().strftime('%H:%M:%S')}")
        # results are in random order so we sort them to make validation easier
        return list(sorted(committee)), energy

    def debug_validate(self):
        utils = [self.rix2voter_ut[rix] for rix in self.state]
        for l, r in zip(utils, utils[1:]):
            if l < r:
                raise Exception(f"iterations={self.iterations}, utils={utils}")

    def move(self):
        self.iterations += 1

        # self.debug_validate()
        # print(
        #     f"- iteration={self.iterations}, {random.random()} sorted state={sorted(self.state)}, "
        #     f"energy={self.energy()}, state={self.state}")

        if self.m > self.k:
            # find a resource to add `add_rix`
            add_rix = random.randrange(0, self.m)
            while add_rix in self.state:
                add_rix = random.randrange(0, self.m)

            # find a resource to remove 'remove_rix'
            remove_ix = random.randrange(0, self.k)
            remove_rix = self.state[remove_ix]
            if self.debug:
                # find the value to remove in a sorted order, so that we're able to compare algos in debug mode
                remove_rix = sorted(self.state)[remove_ix]
                remove_ix = 0
                while self.state[remove_ix] != remove_rix:
                    remove_ix += 1

            # calculate the removal delta and remove from the state
            removal_score_delta = self.score_delta_remove(self.state, self.state[remove_ix], self.rix2voter_ut[remove_rix])
            del self.state[remove_ix]

            # calculate the addition delta and add to the state
            add_rut = self.rix2voter_ut[add_rix]
            add_ix = 0
            while add_ix < self.k - 1 and self.rix2voter_ut[self.state[add_ix]] > add_rut:
                add_ix += 1
            addition_score_delta = self.score_delta_add(self.state, add_rix, add_rut)
            self.state.insert(add_ix, add_rix)

            # print(f"    add_rix={add_rix}, remove_rix={remove_rix}, remove_ix={remove_ix}, dE={- (addition_score_delta + removal_score_delta)} = -({addition_score_delta} + {removal_score_delta})")

            return - (addition_score_delta + removal_score_delta)
        else:
            return 0

    def energy(self):
        score = 0.0
        for voter in self.pref_profile:
            utilities = sorted([voter[cix] for cix in self.state if cix in voter], reverse=True)
            for utility, owa in zip(utilities, self.owa_vector):
                # print(utility, owa)
                score += utility * owa
        if self.verbose > 1 and not self.iterations % 1000:
            print(f"it: {self.iterations}, score = {score}, elapsed = {time.time() - self.last_timestamp:.2f} sec")
        # print(f'energy calculated: {-score}')
        return - score

    # returns the delta of the `sorted_rixs` committee (with rixs sorted by resource utilities)
    # after the addition of the committee index `add_ix` with utility `add_rut`
    def score_delta_add(self, sorted_rixs, add_rix, add_rut):
        score_delta = 0
        approving_voters = self.resource_ix2approving_voters[add_rix]
        for voter in approving_voters:
            utilities = [voter.approvals[cix] for cix in sorted_rixs if cix in voter.approvals]

            add_ix = 0
            while add_ix < len(utilities) and utilities[add_ix] > add_rut:
                add_ix += 1

            for ix in range(add_ix, len(utilities)):
                score_delta += utilities[ix] * self.owa_delta[ix]

            score_delta += add_rut * self.owa_vector[add_ix]

        return score_delta

    # returns the delta of the `sorted_rixs` committee (with rixs sorted by resource utilities)
    # after the removal of the committee index `remove_ix` with utility `remove_rut`
    def score_delta_remove(self, sorted_rixs, remove_rix, remove_rut):
        score_delta = 0
        approving_voters = self.resource_ix2approving_voters[remove_rix]
        for voter in approving_voters:
            utilities = [voter.approvals[cix] for cix in sorted_rixs if cix in voter.approvals]

            remove_ix = 0
            while remove_ix < len(utilities) and utilities[remove_ix] > remove_rut:
                remove_ix += 1

            # sum delta for each 'promoted' resource
            for ix in range(remove_ix + 1, len(utilities)):
                score_delta += utilities[ix] * (-self.owa_delta[ix - 1])

            score_delta -= remove_rut * self.owa_vector[remove_ix]

        return score_delta
