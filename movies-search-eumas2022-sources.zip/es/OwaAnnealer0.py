import random
import time
from datetime import datetime
from typing import List, Dict

from simanneal import Annealer


class OwaAnnealer0(Annealer):

    def __init__(self, m, k, pref_profile: List[Dict[int, float]], owa_vector: List[float], verbose=0):
        self.debug = True
        self.verbose = verbose
        assert pref_profile, "profile must not be empty"
        self.n = len(pref_profile)
        self.m = m
        state = random.sample(list(range(self.m)), k)
        print(f'first state= {sorted(state)}')
        state = sorted(state)
        print(f'initial state = {state}')
        self.k = len(state)
        assert len(state) == self.k, f"state must be of len {self.k}"
        assert len(owa_vector) >= self.k, f"owa vector must be longer than k={self.k}"
        self.pref_profile = pref_profile
        self.owa_vector = owa_vector
        self.iterations = 0
        self.last_timestamp = time.time()
        # self.copy_strategy = "deepcopy"
        super().__init__(state)

    def run(self, settings=None):
        default_minutes = 5
        # anneal_settings = {'tmax': 8100.0, 'tmin': 2.6, 'steps': 20000, 'updates': 100}
        if not settings:
            print(f"estimating anneal settings to target: {default_minutes} "
                  f"minutes calculation time @ {datetime.now().strftime('%H:%M:%S')}")
            settings = self.auto(minutes=default_minutes)
        elif 'minutes' in settings:
            print(f"estimating anneal settings to target: {settings['minutes']} "
                  f"minutes calculation time "
                  f"@ {datetime.now().strftime('%H:%M:%S')}")
            settings = self.auto(minutes=settings['minutes'])

        print(f"annealing with: {settings}"
              f"@ {datetime.now().strftime('%H:%M:%S')}")
        self.set_schedule(settings)
        self.copy_strategy = "slice"
        committee, energy = self.anneal()

        print(f"annealing done "
              f"@ {datetime.now().strftime('%H:%M:%S')}")
        # results are in random order so we sort them to make validation easier
        return list(sorted(committee)), energy

    def move(self):
        self.iterations += 1

        # print(
        #     f"- iteration={self.iterations}, {random.random()} sorted state={sorted(self.state)}, "
        #     f"energy={self.energy()}, state={self.state}")

        initial_energy = self.energy()

        if self.m > self.k:
            new_a = random.randrange(0, self.m)
            while new_a in self.state:
                new_a = random.randrange(0, self.m)

            remove_ix = random.randrange(0, self.k)
            if self.debug:
                # find the value to remove in a sorted order, so that we're able to compare algos in debug mode
                remove_rix = sorted(self.state)[remove_ix]
                remove_ix = 0
                while self.state[remove_ix] != remove_rix:
                    remove_ix += 1

            del self.state[remove_ix]
            self.state.append(new_a)  # .insert(bisect(self.state, new_a), new_a)

        # print(
        #     f"    add_rix={new_a}, remove_rix={remove_rix}, remove_ix={remove_ix}, dE={self.energy() - initial_energy}")

        return self.energy() - initial_energy

    def energy(self):
        score = 0.0
        for voter in self.pref_profile:
            utilities = sorted([voter[cix] for cix in self.state if cix in voter], reverse=True)
            for utility, owa in zip(utilities, self.owa_vector):
                # print(utility, owa)
                score += utility * owa
        if self.verbose > 1 and not self.iterations % 1000:
            print(f"it: {self.iterations}, score = {score}, elapsed = {time.time() - self.last_timestamp:.2f} sec")
        # print(f'energy calculated0: {-score}')
        return -score

    # def update(self, *args, **kwargs):
    #     # super.update(*args, **kwargs)
    #     pass
