import os
import sys

data_folder = os.path.dirname(sys.modules[__name__].__file__) + "/../in"

data_folder_netflix_raw = f'{data_folder}/netflix_raw'
data_netflix_parquet = f'{data_folder}/netflix_parquet'
data_netflix_1k = f'{data_folder}/netflix_1k'
data_netflix_10k = f'{data_folder}/netflix_10k'
data_netflix_50k = f'{data_folder}/netflix_50k'
data_netflix_100k = f'{data_folder}/netflix_100k'

data_folder_movielens_raw = f'{data_folder}/movielens_raw'
data_movielens_100k = f'{data_folder}/movielens_100k'
data_movielens_1m = f'{data_folder}/movielens_1m'
data_movielens_10m = f'{data_folder}/movielens_10m'
data_movielens_25m = f'{data_folder}/movielens_25m'

data_folder_goodreads_raw = f'{data_folder}/goodbooks-10k'
data_goodreads_parquet = f'{data_folder}/goodreads_parquet'

tables = ['aisles', 'departments', 'order_products__prior', 'order_products__train', 'orders', 'products']
